package cs3500.marblesolitaire.controller;

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * Represents the class that implements the controller for marble solitaire.
 */
public class MarbleSolitaireControllerImpl implements MarbleSolitaireController {
  private final MarbleSolitaireModel model;
  private final MarbleSolitaireView view;
  private final Readable readable;
  private boolean quit;

  /**
   * Constructs a controller given a model, view, and input.
   *
   * @param model    the model object.
   * @param view     the view object.
   * @param readable the readable object.
   * @throws IllegalArgumentException if any of the arguments are null.
   */
  public MarbleSolitaireControllerImpl(
          MarbleSolitaireModel model, MarbleSolitaireView view, Readable readable)
          throws IllegalArgumentException {
    if (model == null || view == null || readable == null) {
      throw new IllegalArgumentException(ErrorStatus.NULL_ARGUMENTS.toString());
    }
    this.model = model;
    this.view = view;
    this.readable = readable;
    this.quit = false;
  }

  /**
   * Starts a new game of marble solitaire.
   *
   * @throws IllegalStateException if the controller is unable to successfully
   *                               read input or transmit output.
   */
  @Override
  public void playGame() throws IllegalStateException {
    Scanner sc = new Scanner(this.readable);

    // While the user has not quit and the game is not over.
    while (!this.model.isGameOver() && !this.quit) {
      this.showBoard();
      this.showScore();
      int[] positions = new int[4];
      this.askForMove(sc, positions);
      int fromRow = positions[0] - 1;
      int fromCol = positions[1] - 1;
      int toRow = positions[2] - 1;
      int toCol = positions[3] - 1;
      this.handleMakeMove(fromRow, fromCol, toRow, toCol);
    }

    // Close the scanner.
    sc.close();

    if (this.quit) {
      this.renderQuit();
    }

    if (this.model.isGameOver()) {
      this.renderGameOver();
    }
  }

  /**
   * Handles making a move.
   * - Will not make a move if the user has quit game.
   * - Will run invalid move if user made an invalid move.
   * - Will make move if user made a valid move.
   *
   * @param fromRow the row index of the from slot.
   * @param fromCol the column index of the from slot.
   * @param toRow   the row index of the to slot.
   * @param toCol   the column index of the to slot.
   */
  private void handleMakeMove(int fromRow, int fromCol, int toRow, int toCol) {
    if (this.quit) {
      return;
    }
    try {
      this.model.move(fromRow, fromCol, toRow, toCol);
    } catch (IllegalArgumentException e) {
      this.renderInvalidMove();
    }
  }

  /**
   * What to display when user quits the game.
   */
  private void renderQuit() {
    this.writeMessage("Game quit!");
    this.writeMessage("State of game when quit:");
    this.showBoard();
    this.showScore();
  }

  /**
   * What to display when user makes an invalid move.
   */
  private void renderInvalidMove() {
    this.writeMessage("Invalid move. Play again.");
  }

  /**
   * What to display when the game is over.
   */
  private void renderGameOver() {
    this.writeMessage("Game over!");
    this.showBoard();
    this.showScore();
  }

  /**
   * Writes message with newline to output.
   *
   * @throws IllegalStateException if IOException occurs.
   */
  private void writeMessage(String message) throws IllegalStateException {
    try {
      this.view.renderMessage(message + "\n");
    } catch (IOException e) {
      throw new IllegalStateException(ErrorStatus.IOEXCEPTION_CAUGHT.toString());
    }
  }

  /**
   * Renders board to output.
   */
  private void showBoard() {
    try {
      this.view.renderBoard();
      this.writeMessage("");
    } catch (IOException e) {
      throw new IllegalStateException(ErrorStatus.IOEXCEPTION_CAUGHT.toString());
    }
  }

  /**
   * Renders score to output.
   */
  private void showScore() {
    this.writeMessage(String.format("Score: %d", this.model.getScore()));
  }

  /**
   * Checks if a string value is a non-negative integer.
   *
   * @param val the value as a string.
   * @return true if the value is non-negative, and false otherwise.
   */
  private boolean isNonNegativeInt(String val) {
    try {
      return Integer.parseInt(val) > 0;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  /**
   * Handles asking user for move inputs.
   * - also handles user quitting the game at any point of input.
   * - will continue asking for input if the input is not numeric or "q".
   *
   * @param sc        the {@code Scanner} object.
   * @param positions the array of positions to be populated.
   * @throws IllegalStateException if readable runs out of inputs.
   */
  private void askForMove(Scanner sc, int[] positions) throws IllegalStateException {
    for (int i = 0; i < 4; i++) {
      try {
        String token = sc.next();
        while ((!this.isNonNegativeInt(token)) && !token.equalsIgnoreCase("q")) {
          token = sc.next();
        }
        if (token.equalsIgnoreCase("q")) {
          this.quit = true;
          return;
        }
        positions[i] = Integer.parseInt(token);
      } catch (NoSuchElementException e) {
        throw new IllegalStateException(ErrorStatus.IOEXCEPTION_CAUGHT.toString());
      }
    }
  }
}
