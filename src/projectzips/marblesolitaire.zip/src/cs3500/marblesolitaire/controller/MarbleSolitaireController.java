package cs3500.marblesolitaire.controller;

/**
 * Represents the controller interface for marble solitaire.
 */
public interface MarbleSolitaireController {

  /**
   * Starts a new game of marble solitaire.
   *
   * @throws IllegalStateException if the controller is unable to successfully
   *                               read input or transmit output.
   */
  void playGame() throws IllegalStateException;
}
