package cs3500.marblesolitaire.view;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * Represents the view class for Triangle Solitaire,
 * where the board is oriented in a triangular shape.
 */
public class TriangleSolitaireTextView extends AbstractMarbleSolitaireTextView {
  /**
   * Constructs a new {@code TriangleSolitaireTextView} given a state
   * and sets its destination output to {@code System.out}.
   *
   * @param state the game state to view.
   * @throws IllegalArgumentException if provided state is null.
   */
  public TriangleSolitaireTextView(MarbleSolitaireModelState state) {
    this(state, System.out);
  }

  /**
   * Constructs a new {@code TriangleSolitaireTextView} given a state and destination.
   *
   * @param state      the game state to view.
   * @param appendable the destination of the output of the view.
   * @throws IllegalArgumentException if any argument is null.
   */
  public TriangleSolitaireTextView(MarbleSolitaireModelState state, Appendable appendable)
          throws IllegalArgumentException {
    super(state, appendable);
  }

  /**
   * Return a string that represents the current state of the board.
   * Outputs the triangular board with the most slots at the bottom.
   *
   * @return the game state as a string
   */
  @Override
  public String toString() {
    StringBuilder boardView = new StringBuilder("");
    String empty = "_";
    String invalid = " ";
    String marble = "O";
    String space = " ";
    for (int i = 0; i < this.state.getBoardSize(); i++) {
      for (int j = 0; j < this.state.getBoardSize() - i - 1; j++) {
        boardView.append(invalid);
      }
      for (int j = 0; j < this.state.getBoardSize(); j++) {
        MarbleSolitaireModelState.SlotState slot = this.state.getSlotAt(i, j);
        if (slot == MarbleSolitaireModelState.SlotState.Marble) {
          boardView.append(marble).append(space);
        } else if (slot == MarbleSolitaireModelState.SlotState.Empty) {
          boardView.append(empty).append(space);
        }
      }
      // Remove the last space in the row.
      boardView.deleteCharAt(boardView.length() - 1);
      // Add a newline for the next row.
      boardView.append("\n");
    }

    // Removes the last newline character.
    boardView.deleteCharAt(boardView.length() - 1);
    return boardView.toString();
  }
}
