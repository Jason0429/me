package cs3500.marblesolitaire.view;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * Represents the class for a text view of the game.
 */
public class MarbleSolitaireTextView extends AbstractMarbleSolitaireTextView {
  /**
   * Constructs a new {@code MarbleSolitaireTextView} given a state
   * and sets its destination output to {@code System.out}.
   *
   * @param state the game state to view.
   * @throws IllegalArgumentException if provided state is null.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState state)
          throws IllegalArgumentException {
    this(state, System.out);
  }

  /**
   * Constructs a new {@code MarbleSolitaireTextView} given a state and destination.
   *
   * @param state      the game state to view.
   * @param appendable the destination of the output of the view.
   * @throws IllegalArgumentException if any argument is null.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState state, Appendable appendable)
          throws IllegalArgumentException {
    super(state, appendable);
  }

  /**
   * Return a string that represents the current state of the board. The
   * string should have one line per row of the game board. Each slot on the
   * game board is a single character (O, _ or space for a marble, empty and
   * invalid position respectively). Slots in a row should be separated by a
   * space. Each row has no space before the first slot and after the last slot.
   *
   * @return the game state as a string
   */
  @Override
  public String toString() {
    StringBuilder boardView = new StringBuilder("");
    String emptyChar = "_";
    String invalidChar = " ";
    String marbleChar = "O";
    String space = " ";
    for (int i = 0; i < this.state.getBoardSize(); i++) {
      for (int j = 0; j < this.state.getBoardSize(); j++) {
        MarbleSolitaireModelState.SlotState item = this.state.getSlotAt(i, j);
        switch (item) {
          case Empty:
            boardView.append(emptyChar).append(space);
            break;
          case Invalid:
            boardView.append(invalidChar).append(space);
            break;
          case Marble:
            boardView.append(marbleChar).append(space);
            break;
          default:
            break;
        }
      }

      // Remove the trailing whitespace in the row.
      boardView = this.trimRight(boardView);
      // Add a newline for the next row.
      boardView.append("\n");
    }

    // Removes the last newline character.
    boardView.deleteCharAt(boardView.length() - 1);
    return boardView.toString();
  }
}
