package cs3500.marblesolitaire.model.hw02;

import java.awt.Point;

import cs3500.marblesolitaire.model.hw04.AbstractMarbleSolitaireModel;

/**
 * Represents a class for English Solitaire model.
 * Handles the functionality of the game.
 */
public class EnglishSolitaireModel extends AbstractMarbleSolitaireModel {
  private static final int DEFAULT_SIZE = 3;

  /**
   * Default constructor that sets the {@code armThickness} to default value
   * and sets empty slot to center.
   */
  public EnglishSolitaireModel() {
    this(EnglishSolitaireModel.DEFAULT_SIZE);
  }

  /**
   * Constructor that sets the initial empty slot to a user-specified position.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if empty slot position is invalid.
   */
  public EnglishSolitaireModel(int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this(EnglishSolitaireModel.DEFAULT_SIZE, emptySlotRow, emptySlotCol);
  }

  /**
   * Constructor that sets the {@code size} of the board
   * to a user-specified number and sets empty slot to center.
   *
   * @param size the number of marbles at the top/bottom row of the board.
   * @throws IllegalArgumentException if arm thickness is not a positive odd integer.
   */
  public EnglishSolitaireModel(int size)
          throws IllegalArgumentException {
    this(size, (size + (2 * (size - 1))) / 2,
            (size + (2 * (size - 1))) / 2);
  }

  /**
   * Constructor that allows customization of the {@code size} and initial empty slot.
   *
   * @param size         the number of marbles at the top/bottom row of the board.
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if arm thickness is not a positive odd integer
   *                                  or empty slot position is invalid.
   */
  public EnglishSolitaireModel(int size, int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    super(size, emptySlotRow, emptySlotCol);
  }

  /**
   * Throws an exception if the size is non-positive or even.
   *
   * @param size the size of the board.
   * @throws IllegalArgumentException if the size is non-positive or even.
   */
  protected void checkValidSize(int size) throws IllegalArgumentException {
    if (size <= 0 || size % 2 == 0) {
      throw new IllegalArgumentException(ErrorStatus.POSITIVE_ODD_INTEGER.toString());
    }
  }

  /**
   * Returns true if the position:
   * - is within the board.
   * - is not one of the invalid cells.
   *
   * @param row the row index of a slot.
   * @param col the column index of a slot.
   * @return if row and column indices are valid.
   */
  @Override
  protected boolean isValidPosition(int row, int col) {
    int size = this.getBoardSize();
    if (row < 0 || col < 0 || row >= size || col >= size) {
      return false;
    }
    int invalidRange = this.size - 1;
    boolean isTopLeft = row < invalidRange && col < invalidRange;
    boolean isTopRight = row < invalidRange && col >= size - invalidRange;
    boolean isBottomLeft = row >= size - invalidRange && col < invalidRange;
    boolean isBottomRight = row >= size - invalidRange
            && col >= size - invalidRange;
    return !isTopLeft && !isTopRight && !isBottomLeft && !isBottomRight;
  }

  /**
   * Returns an array of row and column deltas to be added
   * to a slot position that determines a possible move in that direction.
   *
   * @return an array of {@code Point} that holds row and column delta values.
   */
  @Override
  protected Point[] getMovementDeltas() {
    return new Point[]{new Point(0, -2), new Point(0, 2), new Point(-2, 0), new Point(2, 0)};
  }

  /**
   * Returns the row and column index of the slot that exists between two slots
   * while making a move.
   * - The from and to positions must be a valid move before calling this method.
   *
   * @param fromRow the row index of the from slot.
   * @param fromCol the column index of the from slot.
   * @param toRow   the row index of the to slot.
   * @param toCol   the column index of the to slot.
   * @return the row and column indices of the slot between as a {@code Point}.
   */
  protected Point getPositionBetween(int fromRow, int fromCol, int toRow, int toCol) {
    boolean isHoriz = fromRow == toRow;
    int betweenRow = isHoriz ? fromRow : (fromRow + toRow) / 2;
    int betweenCol = isHoriz ? (fromCol + toCol) / 2 : fromCol;
    return new Point(betweenRow, betweenCol);
  }

  /**
   * Returns true if a valid move can be made between the given positions.
   * Rules of a legal move varies across each implementation of marble solitaire.
   *
   * @param fromRow the row index of the from slot.
   * @param fromCol the column index of the from slot.
   * @param toRow   the row index of the to slot.
   * @param toCol   the column index of the to slot.
   * @return true if a valid move can be made, and false otherwise.
   */
  @Override
  protected boolean isValidMove(int fromRow, int fromCol, int toRow, int toCol) {
    SlotState from = this.getSlotAt(fromRow, fromCol);
    SlotState to = this.getSlotAt(toRow, toCol);
    boolean areValidPieces = from == SlotState.Marble && to == SlotState.Empty;
    boolean onlyHorizOrVert = fromRow == toRow ^ fromCol == toCol;
    boolean areTwoApart = Math.abs(fromCol - toCol) == 2 ^ Math.abs(fromRow - toRow) == 2;
    if (!areValidPieces || !onlyHorizOrVert || !areTwoApart) {
      return false;
    }
    Point betweenCoords = this.getPositionBetween(fromRow, fromCol, toRow, toCol);
    return this.getSlotAt(betweenCoords.x, betweenCoords.y) == SlotState.Marble;
  }

  /**
   * Return the size of this board. The size is roughly the longest dimension of a board.
   *
   * @return the size as an integer.
   */
  @Override
  public int getBoardSize() {
    return this.size + (2 * (this.size - 1));
  }
}
