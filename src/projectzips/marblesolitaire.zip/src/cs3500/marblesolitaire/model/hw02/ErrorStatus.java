package cs3500.marblesolitaire.model.hw02;

/**
 * Enumerates error messages.
 */
public enum ErrorStatus {
  INVALID_MOVE("Invalid move."),
  POSITIVE_ODD_INTEGER("Size must be a positive odd integer."),
  POSITIVE_INTEGER("Size must be a positive integer."),
  INVALID_EMPTY_SLOT("Invalid empty cell position (%d,%d)"),
  OUT_OF_DIMENSION("Positions out of dimensions of the board."),
  IOEXCEPTION_THROWN("IOException was thrown."),
  NULL_ARGUMENTS("Cannot accept null arguments."),
  IOEXCEPTION_CAUGHT("IOException was caught."),
  INVALID_COMMAND_LINE_ARG("Invalid command line argument.");

  private final String message;

  ErrorStatus(String message) {
    this.message = message;
  }

  @Override
  public String toString() {
    return this.message;
  }
}
