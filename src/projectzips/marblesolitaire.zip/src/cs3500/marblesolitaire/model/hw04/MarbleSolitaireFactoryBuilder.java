package cs3500.marblesolitaire.model.hw04;

/**
 * Represents the interface for a factory builder that builds
 * the proper marble solitaire factory.
 */
public interface MarbleSolitaireFactoryBuilder {
  /**
   * Sets the size of the model.
   *
   * @param size the size of the game board.
   */
  void size(int size);

  /**
   * Sets the empty slot position of the model.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   */
  void hole(int emptySlotRow, int emptySlotCol);

  MarbleSolitaireFactory build();
}
