package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * Represents an interface to abstract factory methods to create
 * correctly corresponding models and views for each variant of solitaire.
 */
public interface MarbleSolitaireFactory {
  /**
   * Creates and returns the proper marble solitaire model.
   *
   * @return a new instance of a marble solitaire model.
   */
  MarbleSolitaireModel createModel();

  /**
   * Creates and returns the proper view object.
   *
   * @return a new instance of a marble solitaire view.
   */
  MarbleSolitaireView createView();

  /**
   * Creates a returns the proper view object with a given appendable destination output.
   *
   * @param ap the appendable object.
   * @return a new instance of a marble solitaire view.
   */
  MarbleSolitaireView createView(Appendable ap);
}
