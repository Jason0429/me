package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * Represents a factory class for English Marble Solitaire that handles
 * the correct creation of its model and view.
 */
public class EnglishSolitaireFactory implements MarbleSolitaireFactory {
  private final MarbleSolitaireModel model;

  /**
   * Initializes an instance of {@code EnglishSolitaireModel} with the default
   * length and empty slot position.
   */
  public EnglishSolitaireFactory() {
    this.model = new EnglishSolitaireModel();
  }

  /**
   * Initializes an instance of {@code EnglishSolitaireModel} with the
   * specified length and empty slot in the center.
   *
   * @param length the length of the game board.
   * @throws IllegalArgumentException if {@code length} is invalid.
   */
  public EnglishSolitaireFactory(int length) throws IllegalArgumentException {
    this.model = new EnglishSolitaireModel(length);
  }

  /**
   * Initializes an instance of {@code EnglishSolitaireModel} with the
   * default length and the specified empty slot position.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if {@code emptySlotRow} or {@code emptySlotCol} is invalid.
   */
  public EnglishSolitaireFactory(int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this.model = new EnglishSolitaireModel(emptySlotRow, emptySlotCol);
  }

  /**
   * Initializes an instance of {@code EnglishSolitaireModel} with the
   * specified length and empty slot position.
   *
   * @param length       the length of the game board.
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if {@code length}, {@code emptySlotRow}, or
   *                                  {@code emptySlotCol} is invalid.
   */
  public EnglishSolitaireFactory(int length, int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this.model = new EnglishSolitaireModel(length, emptySlotRow, emptySlotCol);
  }

  /**
   * Creates and returns the proper marble solitaire model.
   *
   * @return a new instance of a marble solitaire model.
   */
  @Override
  public MarbleSolitaireModel createModel() {
    return this.model;
  }

  /**
   * Creates and returns the proper view object.
   *
   * @return a new instance of a marble solitaire view.
   */
  @Override
  public MarbleSolitaireView createView() {
    return new MarbleSolitaireTextView(this.model);
  }

  /**
   * Creates a returns the proper view object with a given appendable destination output.
   *
   * @param ap the appendable object.
   * @return a new instance of a marble solitaire view.
   */
  @Override
  public MarbleSolitaireView createView(Appendable ap) {
    return new MarbleSolitaireTextView(this.model, ap);
  }
}
