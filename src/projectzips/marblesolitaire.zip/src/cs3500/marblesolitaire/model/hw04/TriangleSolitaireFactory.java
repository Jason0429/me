package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireView;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

/**
 * Represents a factory class for Triangle Marble Solitaire that handles
 * the correct creation of its model and view.
 */
public class TriangleSolitaireFactory implements MarbleSolitaireFactory {
  private final MarbleSolitaireModel model;

  /**
   * Initializes an instance of {@code TriangleSolitaireModel} with the default
   * length, empty slot row, and empty slot column indices.
   */
  public TriangleSolitaireFactory() {
    this.model = new TriangleSolitaireModel();
  }

  /**
   * Initializes an instance of {@code TriangleSolitaireModel} with the
   * specified length and empty slot in the center.
   *
   * @param length the length of the game board.
   * @throws IllegalArgumentException if {@code length} is invalid.
   */
  public TriangleSolitaireFactory(int length) throws IllegalArgumentException {
    this.model = new TriangleSolitaireModel(length);
  }

  /**
   * Initializes an instance of {@code TriangleSolitaireModel} with the
   * default length and the specified empty slot position.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if {@code emptySlotRow} or {@code emptySlotCol} is invalid.
   */
  public TriangleSolitaireFactory(int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this.model = new TriangleSolitaireModel(emptySlotRow, emptySlotCol);
  }

  /**
   * Initializes an instance of {@code TriangleSolitaireModel} with the
   * specified length and empty slot position.
   *
   * @param length       the length of the game board.
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if {@code length}, {@code emptySlotRow}, or
   *                                  {@code emptySlotCol} is invalid.
   */
  public TriangleSolitaireFactory(int length, int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this.model = new TriangleSolitaireModel(length, emptySlotRow, emptySlotCol);
  }

  /**
   * Creates and returns the proper marble solitaire model.
   *
   * @return a new instance of a marble solitaire model.
   */
  @Override
  public MarbleSolitaireModel createModel() {
    return this.model;
  }

  /**
   * Creates and returns the proper view object.
   *
   * @return a new instance of a marble solitaire view.
   */
  @Override
  public MarbleSolitaireView createView() {
    return new TriangleSolitaireTextView(this.model);
  }

  /**
   * Creates a returns the proper view object with a given appendable destination output.
   *
   * @param ap the appendable object.
   * @return a new instance of a marble solitaire view.
   */
  @Override
  public MarbleSolitaireView createView(Appendable ap) {
    return new TriangleSolitaireTextView(this.model, ap);
  }
}
