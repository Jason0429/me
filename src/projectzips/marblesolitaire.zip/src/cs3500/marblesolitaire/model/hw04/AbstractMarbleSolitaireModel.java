package cs3500.marblesolitaire.model.hw04;

import java.awt.Point;

import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;

/**
 * Represents an abstract model class for Marble Solitaire that
 * holds common functionality between the different variations of solitaires.
 */
public abstract class AbstractMarbleSolitaireModel implements MarbleSolitaireModel {
  protected final int size;
  protected final SlotState[][] board;

  /**
   * Constructs a common marble solitaire model with a specified size,
   * empty slot, and the possible directions a slot can move in.
   *
   * @param size         the number of marbles at the top/bottom row of the board.
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if length is negative or empty slot position is invalid.
   */
  public AbstractMarbleSolitaireModel(int size, int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this.checkValidSize(size);
    // Do not move. Needed for getBoardSize().
    this.size = size;
    this.checkValidEmptySlot(emptySlotRow, emptySlotCol);
    this.board = this.makeBoard(emptySlotRow, emptySlotCol);
  }

  /**
   * Return the size of this board. The size is roughly the longest dimension of a board.
   *
   * @return the size as an integer.
   */
  @Override
  public abstract int getBoardSize();

  /**
   * Throws an exception if the length does not fit the proper criteria.
   *
   * @param length the length of the board.
   * @throws IllegalArgumentException if the length is invalid.
   */
  protected abstract void checkValidSize(int length) throws IllegalArgumentException;

  /**
   * Returns an array of row and column deltas to be added
   * to a slot position that determines a possible move in that direction.
   *
   * @return an array of {@code Point} that holds row and column delta values.
   */
  protected abstract Point[] getMovementDeltas();

  /**
   * Returns true if the given position is a valid slot on the board.
   * Implementation of valid position varies across the solitaires.
   *
   * @param row the row index of the slot.
   * @param col the column index of the slot.
   * @return true if the given position is a valid slot, and false otherwise.
   */
  protected abstract boolean isValidPosition(int row, int col);

  /**
   * Returns the row and column index of the slot that exists between two slots
   * while making a move.
   * - The from and to positions must be a valid move before calling this method.
   *
   * @param fromRow the row index of the from slot.
   * @param fromCol the column index of the from slot.
   * @param toRow   the row index of the to slot.
   * @param toCol   the column index of the to slot.
   * @return the row and column indices of the slot between as a {@code Point}.
   */
  protected abstract Point getPositionBetween(int fromRow, int fromCol, int toRow, int toCol);

  /**
   * Returns true if a valid move can be made between the given positions.
   * Rules of a legal move varies across each implementation of marble solitaire.
   *
   * @param fromRow the row index of the from slot.
   * @param fromCol the column index of the from slot.
   * @param toRow   the row index of the to slot.
   * @param toCol   the column index of the to slot.
   * @return true if a valid move can be made, and false otherwise.
   */
  protected abstract boolean isValidMove(int fromRow, int fromCol, int toRow, int toCol);

  /**
   * Determine and return if the game is over or not. A game is over if no
   * more moves can be made.
   *
   * @return true if the game is over, false otherwise.
   */
  @Override
  public boolean isGameOver() {
    for (int i = 0; i < this.getBoardSize(); i++) {
      for (int j = 0; j < this.getBoardSize(); j++) {
        if (this.getSlotAt(i, j) == SlotState.Marble) {
          if (this.canMakeMove(i, j)) {
            return false;
          }
        }
      }
    }
    return true;
  }

  /**
   * Move a single marble from a given position to another given position.
   * A move is valid only if the from and to positions are valid. Specific
   * implementations may place additional constraints on the validity of a move.
   *
   * @param fromRow the row number of the position to be moved from
   *                (starts at 0).
   * @param fromCol the column number of the position to be moved from
   *                (starts at 0).
   * @param toRow   the row number of the position to be moved to
   *                (starts at 0).
   * @param toCol   the column number of the position to be moved to
   *                (starts at 0).
   * @throws IllegalArgumentException if the move is not possible.
   */
  @Override
  public void move(int fromRow, int fromCol, int toRow, int toCol)
          throws IllegalArgumentException {
    if (!this.isValidPosition(fromRow, fromCol) || !this.isValidPosition(toRow, toCol)) {
      throw new IllegalArgumentException(ErrorStatus.INVALID_MOVE.toString());
    }
    if (!this.isValidMove(fromRow, fromCol, toRow, toCol)) {
      throw new IllegalArgumentException(ErrorStatus.INVALID_MOVE.toString());
    }
    Point betweenCoords = this.getPositionBetween(fromRow, fromCol, toRow, toCol);
    this.board[fromRow][fromCol] = SlotState.Empty;
    this.board[betweenCoords.x][betweenCoords.y] = SlotState.Empty;
    this.board[toRow][toCol] = SlotState.Marble;
  }

  /**
   * Get the state of the slot at a given position on the board.
   *
   * @param row the row of the position sought, starting at 0.
   * @param col the column of the position sought, starting at 0.
   * @return the state of the slot at the given row and column.
   * @throws IllegalArgumentException if the row or the column are beyond
   *                                  the dimensions of the board.
   */
  @Override
  public SlotState getSlotAt(int row, int col) {
    if (row < 0 || row >= this.getBoardSize()
            || col < 0 || col >= this.getBoardSize()) {
      throw new IllegalArgumentException(ErrorStatus.OUT_OF_DIMENSION.toString());
    }
    return this.board[row][col];
  }

  /**
   * Return the number of marbles currently on the board.
   *
   * @return the number of marbles currently on the board.
   */
  @Override
  public int getScore() {
    int marblesCount = 0;
    for (int i = 0; i < this.getBoardSize(); i++) {
      for (int j = 0; j < this.getBoardSize(); j++) {
        if (this.getSlotAt(i, j) == SlotState.Marble) {
          marblesCount++;
        }
      }
    }
    return marblesCount;
  }

  /**
   * Returns a new 2D array representing the marble solitaire game board with an
   * empty slot at the given position.
   *
   * @param emptySlotRow the empty row position.
   * @param emptySlotCol the empty column position.
   * @return the game board as a 2D array.
   */
  private SlotState[][] makeBoard(int emptySlotRow, int emptySlotCol) {
    int size = this.getBoardSize();
    SlotState[][] board = new SlotState[size][size];

    for (int i = 0; i < board.length; i++) {
      SlotState[] row = new SlotState[size];
      for (int j = 0; j < row.length; j++) {
        if (i == emptySlotRow && j == emptySlotCol) {
          row[j] = SlotState.Empty;
        } else if (this.isValidPosition(i, j)) {
          row[j] = SlotState.Marble;
        } else {
          row[j] = SlotState.Invalid;
        }
      }
      board[i] = row;
    }

    return board;
  }

  /**
   * Determines if this marble can make a valid move.
   * - Slot at this position must be a marble.
   *
   * @param fromRow the marble's row index from where it is being moved from.
   * @param fromCol the marble's column index from where it is being moved from.
   */
  private boolean canMakeMove(int fromRow, int fromCol) {
    Point[] movementDeltas = this.getMovementDeltas();
    for (Point delta : movementDeltas) {
      int toRow = fromRow + delta.x;
      int toCol = fromCol + delta.y;
      if (this.isValidPosition(toRow, toCol)
              && this.isValidMove(fromRow, fromCol, toRow, toCol)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Throws exception if the provided empty slot row and column indices are not valid.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if the empty slot row and column indices are not valid.
   */
  private void checkValidEmptySlot(int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    if (!this.isValidPosition(emptySlotRow, emptySlotCol)) {
      throw new IllegalArgumentException(
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), emptySlotRow, emptySlotCol));
    }
  }
}
