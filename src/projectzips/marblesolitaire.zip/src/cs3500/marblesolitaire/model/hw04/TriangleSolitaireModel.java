package cs3500.marblesolitaire.model.hw04;

import java.awt.Point;

import cs3500.marblesolitaire.model.hw02.ErrorStatus;

/**
 * Represents the model class for Triangle Marble Solitaire,
 * where the board is oriented in a triangular shape.
 */
public class TriangleSolitaireModel extends AbstractMarbleSolitaireModel {
  private static final int DEFAULT_SIZE = 5;

  /**
   * Constructs a Triangle solitaire model with a default size
   * and an empty slot at (0, 0).
   */
  public TriangleSolitaireModel() {
    this(TriangleSolitaireModel.DEFAULT_SIZE);
  }

  /**
   * Constructs a Triangle solitaire model with a specified size
   * and an empty slot at (0, 0).
   *
   * @param size the number of slots in the bottom row.
   * @throws IllegalArgumentException if the size is not a positive integer.
   */
  public TriangleSolitaireModel(int size) throws IllegalArgumentException {
    this(size, 0, 0);
  }

  /**
   * Constructs a Triangle solitaire model with a default size
   * and an empty slot at the specified position.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if the empty slot position is invalid.
   */
  public TriangleSolitaireModel(int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this(TriangleSolitaireModel.DEFAULT_SIZE, emptySlotRow, emptySlotCol);
  }

  /**
   * Constructs a Triangle solitaire model with a specified size
   * and an empty slot at the specified position.
   *
   * @param size         the number of slots in the bottom row.
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if the size is not a positive integer or
   *                                  the empty slot position is invalid.
   */
  public TriangleSolitaireModel(int size, int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    super(size, emptySlotRow, emptySlotCol);
  }

  /**
   * Throws an exception if the size is non-positive.
   *
   * @param size the length of the board.
   * @throws IllegalArgumentException if the length is non-positive.
   */
  @Override
  protected void checkValidSize(int size) throws IllegalArgumentException {
    if (size <= 0) {
      throw new IllegalArgumentException(ErrorStatus.POSITIVE_INTEGER.toString());
    }
  }

  /**
   * Returns an array of row and column deltas to be added
   * to a slot position that determines a possible move in that direction.
   *
   * @return an array of {@code Point} that holds row and column delta values.
   */
  @Override
  protected Point[] getMovementDeltas() {
    return new Point[]{new Point(0, -2), new Point(0, 2), new Point(-2, 0),
                       new Point(2, 0), new Point(2, 2), new Point(-2, -2)};
  }

  /**
   * Returns true if the given position is a valid slot on the board.
   * A valid slot:
   * - is on the game board.
   * - has a column index less than or equal to the row index.
   *
   * @param row the row index of the slot.
   * @param col the column index of the slot.
   * @return true if the given position is a valid slot, and false otherwise.
   */
  @Override
  protected boolean isValidPosition(int row, int col) {
    return col <= row && row < this.getBoardSize() && col >= 0;
  }

  /**
   * Returns the row and column index of the marble that exists between two points
   * while making a move.
   * - The from and to positions must be a valid move before calling this method.
   *
   * @param fromRow the row index of the from slot.
   * @param fromCol the column index of the from slot.
   * @param toRow   the row index of the to slot.
   * @param toCol   the column index of the to slot.
   * @return the row and column indices of the marble between as a {@code Point}.
   */
  @Override
  protected Point getPositionBetween(int fromRow, int fromCol, int toRow, int toCol) {
    int betweenRow = (fromRow + toRow) / 2;
    int betweenCol = (fromCol + toCol) / 2;

    if (fromCol == toCol) { // Vertical
      return new Point(betweenRow, fromCol);
    } else if (fromRow == toRow) { //Horizontal
      return new Point(fromRow, betweenCol);
    }
    return new Point(betweenRow, betweenCol);
  }

  /**
   * Returns true if a valid move can be made between the given positions.
   *
   * @param fromRow the row index of the from slot.
   * @param fromCol the column index of the from slot.
   * @param toRow   the row index of the to slot.
   * @param toCol   the column index of the to slot.
   * @return true if a valid move can be made, and false otherwise.
   */
  @Override
  protected boolean isValidMove(int fromRow, int fromCol, int toRow, int toCol) {
    SlotState from = this.getSlotAt(fromRow, fromCol);
    SlotState to = this.getSlotAt(toRow, toCol);
    boolean areValidPieces = from == SlotState.Marble && to == SlotState.Empty;
    boolean areTwoApart =
            // Check vertical two apart
            (fromCol == toCol && Math.abs(fromRow - toRow) == 2)
                    // Check horizontal two apart
                    || (fromRow == toRow && Math.abs(fromCol - toCol) == 2)
                    // Check slant right two apart
                    || (fromRow != toRow && fromCol != toCol
                    && Math.abs(fromRow - toRow) == 2 && Math.abs(fromCol - toCol) == 2);
    if (!areValidPieces || !areTwoApart) {
      return false;
    }
    Point betweenCoords = this.getPositionBetween(fromRow, fromCol, toRow, toCol);
    return this.getSlotAt(betweenCoords.x, betweenCoords.y) == SlotState.Marble;
  }

  /**
   * Return the size of this board. The size is roughly the longest dimension of a board.
   *
   * @return the size as an integer.
   */
  @Override
  public int getBoardSize() {
    return this.size;
  }
}
