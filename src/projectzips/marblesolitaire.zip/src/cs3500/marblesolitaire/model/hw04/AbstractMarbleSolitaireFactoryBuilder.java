package cs3500.marblesolitaire.model.hw04;

/**
 * Represents the abstract builder class for building
 * a marble solitaire factory. All variations of the solitaire factory builder will
 * extend this.
 */
public abstract class AbstractMarbleSolitaireFactoryBuilder
        implements MarbleSolitaireFactoryBuilder {
  protected int size;
  protected int emptySlotRow;
  protected int emptySlotCol;
  protected boolean hasInputSize;
  protected boolean hasInputHole;

  /**
   * Constructs an instance indicating that there has been no
   * specified size or hole yet.
   */
  public AbstractMarbleSolitaireFactoryBuilder() {
    this.hasInputSize = false;
    this.hasInputHole = false;
  }

  /**
   * Builds and returns a new {@code MarbleSolitaireFactory}.
   *
   * @return a new {@code MarbleSolitaireFactory}.
   */
  @Override
  public abstract MarbleSolitaireFactory build();

  /**
   * Sets the size of the solitaire model.
   */
  @Override
  public void size(int size) {
    this.size = size;
    this.hasInputSize = true;
  }

  /**
   * Sets the row and column index of the empty slot position on the board.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   */
  @Override
  public void hole(int emptySlotRow, int emptySlotCol) {
    this.emptySlotRow = emptySlotRow;
    this.emptySlotCol = emptySlotCol;
    this.hasInputHole = true;
  }
}
