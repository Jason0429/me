package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;

/**
 * Represents the model class for European Marble Solitaire,
 * where the board is oriented in an octagon shape.
 */
public class EuropeanSolitaireModel extends EnglishSolitaireModel {
  private static final int DEFAULT_SIZE = 3;

  /**
   * Default constructor that sets the length of the board to 3
   * and empty slot to the center of the board.
   */
  public EuropeanSolitaireModel() {
    this(EuropeanSolitaireModel.DEFAULT_SIZE);
  }

  /**
   * Constructor that sets a specified size of the board
   * and empty slot to the center of the board.
   *
   * @param size the number of marbles at the sides of the board.
   * @throws IllegalArgumentException if the size is not a positive odd integer.
   */
  public EuropeanSolitaireModel(int size) throws IllegalArgumentException {
    this(size, (size + (2 * (size - 1))) / 2,
            (size + (2 * (size - 1))) / 2);
  }

  /**
   * Constructor that sets the default size of the board
   * and empty slot to the specified position on the board.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if the empty slot is at an invalid position.
   */
  public EuropeanSolitaireModel(int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this(EuropeanSolitaireModel.DEFAULT_SIZE, emptySlotRow, emptySlotCol);
  }

  /**
   * Constructor that sets the size of the board to the specified size
   * and empty slot to the specified position on the board.
   *
   * @param size         the number of marbles at the sides of the board.
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if the size is not a positive odd integer or
   *                                  the empty slot is at an invalid position.
   */
  public EuropeanSolitaireModel(int size, int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    super(size, emptySlotRow, emptySlotCol);
  }

  /**
   * Returns true if the given position is a valid slot on the board.
   * A position is valid if it is within the octagon shape of the board.
   *
   * @param row the row index of the slot.
   * @param col the column index of the slot.
   * @return true if the given position is a valid slot, and false otherwise.
   */
  @Override
  protected boolean isValidPosition(int row, int col) {
    if (row < 0 || col < 0 || row >= this.getBoardSize() || col >= this.getBoardSize()) {
      return false;
    }

    int size = this.getBoardSize();

    // Top left
    for (int i = 0; i < this.size - 1; i++) {
      for (int j = 0; j < this.size - 1 - i; j++) {
        if (i == row && j == col) {
          return false;
        }
      }
    }
    // Top right
    for (int i = 0; i < this.size - 1; i++) {
      for (int j = size - this.size + 1 + i; j < size; j++) {
        if (i == row && j == col) {
          return false;
        }
      }
    }
    // Bottom left
    for (int i = size - this.size + 1; i < size; i++) {
      for (int j = 0; j < this.size - (size - i); j++) {
        if (i == row && j == col) {
          return false;
        }
      }
    }
    // Bottom right
    for (int i = size - this.size + 1; i < size; i++) {
      for (int j = size - (this.size - (size - i)); j < size; j++) {
        if (i == row && j == col) {
          return false;
        }
      }
    }
    return true;
  }
}
