package cs3500.marblesolitaire.model.hw04;

/**
 * Represents the builder class for building an {@code EnglishSolitaireFactory}.
 * Handles setting options and calling proper constructor of the specified model.
 */
public class EnglishSolitaireFactoryBuilder extends AbstractMarbleSolitaireFactoryBuilder {
  /**
   * Constructs a default instance of {@code EnglishSolitaireFactoryBuilder}.
   */
  public EnglishSolitaireFactoryBuilder() {
    super();
  }

  /**
   * Builds and returns a new {@code EnglishSolitaireFactory} based
   * if size and hole options were specified.
   *
   * @return a new {@code EnglishSolitaireFactory}.
   */
  @Override
  public MarbleSolitaireFactory build() {
    if (this.hasInputSize && this.hasInputHole) {
      return new EnglishSolitaireFactory(this.size, this.emptySlotRow, this.emptySlotCol);
    } else if (this.hasInputSize) {
      return new EnglishSolitaireFactory(this.size);
    } else if (this.hasInputHole) {
      return new EnglishSolitaireFactory(this.emptySlotRow, this.emptySlotCol);
    } else {
      return new EnglishSolitaireFactory();
    }
  }
}
