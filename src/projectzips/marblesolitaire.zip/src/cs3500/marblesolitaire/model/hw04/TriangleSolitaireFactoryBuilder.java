package cs3500.marblesolitaire.model.hw04;

/**
 * Represents the builder class for building an {@code TriangleSolitaireFactory}.
 * Handles setting options and calling proper constructor of the specified model.
 */
public class TriangleSolitaireFactoryBuilder extends AbstractMarbleSolitaireFactoryBuilder {
  /**
   * Constructs a default instance of {@code TriangleSolitaireFactoryBuilder}.
   */
  public TriangleSolitaireFactoryBuilder() {
    super();
  }

  /**
   * Builds and returns a new {@code TriangleSolitaireFactory} based
   * if size and hole options were specified.
   *
   * @return a new {@code TriangleSolitaireFactory}.
   */
  @Override
  public MarbleSolitaireFactory build() {
    if (this.hasInputSize && this.hasInputHole) {
      return new TriangleSolitaireFactory(this.size, this.emptySlotRow, this.emptySlotCol);
    } else if (this.hasInputSize) {
      return new TriangleSolitaireFactory(this.size);
    } else if (this.hasInputHole) {
      return new TriangleSolitaireFactory(this.emptySlotRow, this.emptySlotCol);
    } else {
      return new TriangleSolitaireFactory();
    }
  }
}
