package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * Represents a factory class for European Marble Solitaire that handles
 * the correct creation of its model and view.
 */
public class EuropeanSolitaireFactory implements MarbleSolitaireFactory {
  private final MarbleSolitaireModel model;

  /**
   * Initializes an instance of {@code EuropeanSolitaireModel} with the default
   * length, empty slot row, and empty slot column indices.
   */
  public EuropeanSolitaireFactory() {
    this.model = new EuropeanSolitaireModel();
  }

  /**
   * Initializes an instance of {@code EuropeanSolitaireModel} with the
   * specified length and empty slot in the center.
   *
   * @param length the length of the game board.
   * @throws IllegalArgumentException if {@code length} is invalid.
   */
  public EuropeanSolitaireFactory(int length) throws IllegalArgumentException {
    this.model = new EuropeanSolitaireModel(length);
  }

  /**
   * Initializes an instance of {@code EuropeanSolitaireModel} with the
   * default length and the specified empty slot position.
   *
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if {@code emptySlotRow} or {@code emptySlotCol} is invalid.
   */
  public EuropeanSolitaireFactory(int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this.model = new EuropeanSolitaireModel(emptySlotRow, emptySlotCol);
  }

  /**
   * Initializes an instance of {@code EuropeanSolitaireModel} with the
   * specified length and empty slot position.
   *
   * @param length       the length of the game board.
   * @param emptySlotRow the row index of the empty slot.
   * @param emptySlotCol the column index of the empty slot.
   * @throws IllegalArgumentException if {@code length}, {@code emptySlotRow}, or
   *                                  {@code emptySlotCol} is invalid.
   */
  public EuropeanSolitaireFactory(int length, int emptySlotRow, int emptySlotCol)
          throws IllegalArgumentException {
    this.model = new EuropeanSolitaireModel(length, emptySlotRow, emptySlotCol);
  }

  /**
   * Creates and returns the proper marble solitaire model.
   *
   * @return a new instance of a marble solitaire model.
   */
  @Override
  public MarbleSolitaireModel createModel() {
    return this.model;
  }

  /**
   * Creates and returns the proper view object.
   *
   * @return a new instance of a marble solitaire view.
   */
  @Override
  public MarbleSolitaireView createView() {
    return new MarbleSolitaireTextView(this.model);
  }

  /**
   * Creates a returns the proper view object with a given appendable destination output.
   *
   * @param ap the appendable object.
   * @return a new instance of a marble solitaire view.
   */
  @Override
  public MarbleSolitaireView createView(Appendable ap) {
    return new MarbleSolitaireTextView(this.model, ap);
  }
}
