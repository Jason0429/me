package cs3500.marblesolitaire;

import java.io.InputStreamReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw04.EnglishSolitaireFactoryBuilder;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireFactoryBuilder;
import cs3500.marblesolitaire.model.hw04.MarbleSolitaireFactory;
import cs3500.marblesolitaire.model.hw04.MarbleSolitaireFactoryBuilder;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireFactoryBuilder;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * Main class to run and play marble solitaire game.
 */
public class MarbleSolitaire {
  /**
   * The main method to create a model, view, and controller to play the game.
   *
   * @param args command line arguments.
   * @throws IllegalArgumentException if a command line argument is invalid.
   */
  public static void main(String[] args) throws IllegalArgumentException {
    // Set correct factory type.
    String solitaireType = args[0];
    MarbleSolitaireFactoryBuilder factoryBuilder = MarbleSolitaire.getFactoryBuilder(solitaireType);

    // Set size and hole options, if any.
    for (int i = 1; i < args.length; i++) {
      String option = args[i];
      switch (option) {
        case "-size":
          int size = Integer.parseInt(args[++i]);
          factoryBuilder.size(size);
          break;
        case "-hole":
          int emptySlotRow = Integer.parseInt(args[++i]);
          int emptySlotCol = Integer.parseInt(args[++i]);
          factoryBuilder.hole(emptySlotRow, emptySlotCol);
          break;
        default:
          throw new IllegalArgumentException(ErrorStatus.INVALID_COMMAND_LINE_ARG.toString());
      }
    }

    // Create proper model, view, and controller and play.
    MarbleSolitaireFactory factory = factoryBuilder.build();
    MarbleSolitaireModel model = factory.createModel();
    MarbleSolitaireView view = factory.createView();
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, view, new InputStreamReader(System.in));
    controller.playGame();
  }

  /**
   * Returns the proper factory builder object.
   *
   * @param type the type of solitaire as a string.
   * @return a new {@code MarbleSolitaireFactoryBuilder}.
   * @throws IllegalArgumentException if the {@code type} is invalid.
   */
  private static MarbleSolitaireFactoryBuilder getFactoryBuilder(String type)
          throws IllegalArgumentException {
    switch (type) {
      case "english":
        return new EnglishSolitaireFactoryBuilder();
      case "european":
        return new EuropeanSolitaireFactoryBuilder();
      case "triangular":
        return new TriangleSolitaireFactoryBuilder();
      default:
        throw new IllegalArgumentException(ErrorStatus.INVALID_COMMAND_LINE_ARG.toString());
    }
  }
}
