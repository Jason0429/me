import org.junit.Test;
import org.junit.Before;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * Tests for {@code EnglishSolitaireModel}.
 */
public class EnglishSolitaireModelTest {
  private MarbleSolitaireModelState.SlotState marble;
  private MarbleSolitaireModelState.SlotState empty;
  private MarbleSolitaireModelState.SlotState invalid;
  private MarbleSolitaireModel englishModel1;
  private MarbleSolitaireModel englishModel2;
  private MarbleSolitaireModel englishModel3;
  private MarbleSolitaireModel englishModel4;

  @Before
  public void setUp() {
    this.empty = MarbleSolitaireModelState.SlotState.Empty;
    this.marble = MarbleSolitaireModelState.SlotState.Marble;
    this.invalid = MarbleSolitaireModelState.SlotState.Invalid;
    this.englishModel1 = new EnglishSolitaireModel();
    this.englishModel2 = new EnglishSolitaireModel(2, 3);
    this.englishModel3 = new EnglishSolitaireModel(5);
    this.englishModel4 = new EnglishSolitaireModel(3, 2, 3);
  }

  @Test
  public void testEnglishWrongArmThickness1() {
    try {
      new EnglishSolitaireModel(2);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_ODD_INTEGER.toString());
    }
  }

  @Test
  public void testEnglishWrongArmThickness2() {
    try {
      new EnglishSolitaireModel(-1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_ODD_INTEGER.toString());
    }
  }

  @Test
  public void testEnglishWrongArmThickness3() {
    try {
      new EnglishSolitaireModel(2, 3, 3);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_ODD_INTEGER.toString());
    }
  }

  @Test
  public void testEnglishWrongEmptySlotPosition1() {
    try {
      new EnglishSolitaireModel(-1, -1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), -1, -1));
    }
  }

  @Test
  public void testEnglishWrongEmptySlotPosition2() {
    try {
      new EnglishSolitaireModel(1, 1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), 1, 1));
    }
  }

  @Test
  public void testEnglishWrongEmptySlotPosition3() {
    try {
      new EnglishSolitaireModel(5, 0, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), 0, 0));
    }
  }

  @Test
  public void testEnglishMoveLeft() {
    // Game1:
    // Move (3, 5) to (3, 3)
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 5));
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 4));
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 3));
    this.englishModel1.move(3, 5, 3, 3);
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 5));
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 4));
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEnglishMoveRight() {
    // Game1:
    // Move (3, 1) to (3, 3)
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 1));
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 2));
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 3));
    this.englishModel1.move(3, 1, 3, 3);
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 1));
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 2));
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEnglishMoveUp() {
    // Game1:
    // Move (5, 3) to (3, 3)
    assertEquals(this.marble, this.englishModel1.getSlotAt(5, 3));
    assertEquals(this.marble, this.englishModel1.getSlotAt(4, 3));
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 3));
    this.englishModel1.move(5, 3, 3, 3);
    assertEquals(this.empty, this.englishModel1.getSlotAt(5, 3));
    assertEquals(this.empty, this.englishModel1.getSlotAt(4, 3));
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEnglishMoveDown() {
    // Game1:
    // Move (1, 3) to (3, 3)
    assertEquals(this.marble, this.englishModel1.getSlotAt(1, 3));
    assertEquals(this.marble, this.englishModel1.getSlotAt(2, 3));
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 3));
    this.englishModel1.move(1, 3, 3, 3);
    assertEquals(this.empty, this.englishModel1.getSlotAt(1, 3));
    assertEquals(this.empty, this.englishModel1.getSlotAt(2, 3));
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEnglishInvalidMoveDiagonal() {
    try {
      this.englishModel1.move(2, 4, 4, 2);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEnglishInvalidMoveToDoesNotExist() {
    try {
      this.englishModel1.move(3, 1, 9, 9);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEnglishInvalidMoveFromDoesNotHaveMarble() {
    try {
      this.englishModel1.move(0, 0, 2, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEnglishInvalidMoveToIsNotEmpty() {
    try {
      this.englishModel1.move(2, 0, 4, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEnglishInvalidMoveJumpOverEmpty() {
    try {
      this.englishModel1.move(3, 2, 3, 4);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEnglishInvalidMoveMoreThanTwoApart() {
    try {
      this.englishModel1.move(3, 2, 3, 5);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEnglishIsGameOver() {
    MarbleSolitaireModel noMarbles = new EnglishSolitaireModel(1);
    assertTrue(noMarbles.isGameOver());
    assertFalse(this.englishModel1.isGameOver());
  }

  @Test
  public void testEnglishGetSlotAt() {
    assertEquals(this.invalid, this.englishModel1.getSlotAt(0, 0));
    assertEquals(this.marble, this.englishModel1.getSlotAt(3, 2));
    assertEquals(this.empty, this.englishModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEnglishGetScore() {
    assertEquals(32, this.englishModel1.getScore());
    this.englishModel1.move(1, 3, 3, 3);
    assertEquals(31, this.englishModel1.getScore());
    this.englishModel1.move(4, 3, 2, 3);
    assertEquals(30, this.englishModel1.getScore());
  }

  @Test
  public void testEnglishGetBoardSize() {
    assertEquals(7, this.englishModel1.getBoardSize());
    assertEquals(7, this.englishModel2.getBoardSize());
    assertEquals(13, this.englishModel3.getBoardSize());
    assertEquals(7, this.englishModel4.getBoardSize());
  }
}
