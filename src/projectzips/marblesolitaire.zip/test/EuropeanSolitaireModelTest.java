import org.junit.Test;
import org.junit.Before;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;

/**
 * Tests for {@code EuropeanSolitaireModel}.
 */
public class EuropeanSolitaireModelTest {
  private MarbleSolitaireModelState.SlotState marble;
  private MarbleSolitaireModelState.SlotState empty;
  private MarbleSolitaireModelState.SlotState invalid;
  private MarbleSolitaireModel euroModel1;
  private MarbleSolitaireModel euroModel2;
  private MarbleSolitaireModel euroModel3;
  private MarbleSolitaireModel euroModel4;

  @Before
  public void setUp() {
    this.empty = MarbleSolitaireModelState.SlotState.Empty;
    this.marble = MarbleSolitaireModelState.SlotState.Marble;
    this.invalid = MarbleSolitaireModelState.SlotState.Invalid;
    this.euroModel1 = new EuropeanSolitaireModel();
    this.euroModel2 = new EuropeanSolitaireModel(5, 5);
    this.euroModel3 = new EuropeanSolitaireModel(5);
    this.euroModel4 = new EuropeanSolitaireModel(5, 5, 5);
  }

  @Test
  public void testEuroWrongLength1() {
    try {
      new EuropeanSolitaireModel(2);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_ODD_INTEGER.toString());
    }
  }

  @Test
  public void testEuroWrongLength2() {
    try {
      new EuropeanSolitaireModel(-1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_ODD_INTEGER.toString());
    }
  }

  @Test
  public void testEuroWrongLength3() {
    try {
      new EuropeanSolitaireModel(2, 0, 5);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_ODD_INTEGER.toString());
    }
  }

  @Test
  public void testEuroWrongEmptySlotPosition1() {
    try {
      new EuropeanSolitaireModel(-1, -1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), -1, -1));
    }
  }

  @Test
  public void testEuroWrongEmptySlotPosition2() {
    try {
      new EuropeanSolitaireModel(0, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), 0, 0));
    }
  }

  @Test
  public void testEuroWrongEmptySlotPosition3() {
    try {
      new EuropeanSolitaireModel(5, 0, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), 0, 0));
    }
  }

  @Test
  public void testEuroMoveLeft() {
    // Game1:
    // Move (3, 5) to (3, 3)
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 5));
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 4));
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 3));
    this.euroModel1.move(3, 5, 3, 3);
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 5));
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 4));
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEuroMoveRight() {
    // Game1:
    // Move (3, 1) to (3, 3)
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 1));
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 2));
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 3));
    this.euroModel1.move(3, 1, 3, 3);
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 1));
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 2));
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEuroMoveUp() {
    // Game1:
    // Move (5, 3) to (3, 3)
    assertEquals(this.marble, this.euroModel1.getSlotAt(5, 3));
    assertEquals(this.marble, this.euroModel1.getSlotAt(4, 3));
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 3));
    this.euroModel1.move(5, 3, 3, 3);
    assertEquals(this.empty, this.euroModel1.getSlotAt(5, 3));
    assertEquals(this.empty, this.euroModel1.getSlotAt(4, 3));
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEuroMoveDown() {
    // Game1:
    // Move (5, 3) to (3, 3)
    assertEquals(this.marble, this.euroModel1.getSlotAt(5, 3));
    assertEquals(this.marble, this.euroModel1.getSlotAt(4, 3));
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 3));
    this.euroModel1.move(5, 3, 3, 3);
    assertEquals(this.empty, this.euroModel1.getSlotAt(5, 3));
    assertEquals(this.empty, this.euroModel1.getSlotAt(4, 3));
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEuroInvalidMoveDiagonal() {
    try {
      this.euroModel1.move(5, 5, 3, 3);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEuroInvalidMoveToDoesNotExist() {
    try {
      this.euroModel1.move(3, 1, 9, 9);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEuroInvalidMoveFromDoesNotHaveMarble() {
    try {
      this.euroModel1.move(0, 0, 2, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEuroInvalidMoveToIsNotEmpty() {
    try {
      this.euroModel1.move(2, 0, 4, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEuroInvalidMoveJumpOverEmpty() {
    try {
      this.euroModel1.move(3, 2, 3, 4);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEuroInvalidMoveMoreThanTwoApart() {
    try {
      this.euroModel1.move(3, 0, 3, 3);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEuroWrongMoveIntoInvalid() {
    try {
      MarbleSolitaireModel model = new EuropeanSolitaireModel();
      model.move(0, 4, 0, 6);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testEuroIsGameOver() {
    MarbleSolitaireModel noMarbles = new EuropeanSolitaireModel(1);
    assertTrue(noMarbles.isGameOver());
    assertFalse(this.euroModel1.isGameOver());
  }

  @Test
  public void testEuroGetBoardSize() {
    assertEquals(7, this.euroModel1.getBoardSize());
    assertEquals(7, this.euroModel2.getBoardSize());
    assertEquals(13, this.euroModel3.getBoardSize());
    assertEquals(13, this.euroModel4.getBoardSize());
  }

  @Test
  public void testEuroGetSlotAt() {
    assertEquals(this.invalid, this.euroModel1.getSlotAt(0, 0));
    assertEquals(this.marble, this.euroModel1.getSlotAt(3, 2));
    assertEquals(this.empty, this.euroModel1.getSlotAt(3, 3));
  }

  @Test
  public void testEuroGetScore() {
    assertEquals(36, this.euroModel1.getScore());
    this.euroModel1.move(1, 3, 3, 3);
    assertEquals(35, this.euroModel1.getScore());
    this.euroModel1.move(4, 3, 2, 3);
    assertEquals(34, this.euroModel1.getScore());
  }
}
