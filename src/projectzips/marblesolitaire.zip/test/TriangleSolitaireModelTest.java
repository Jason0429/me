import org.junit.Test;
import org.junit.Before;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;

/**
 * Tests for {@code TriangleSolitaireModel}.
 */
public class TriangleSolitaireModelTest {
  private MarbleSolitaireModelState.SlotState marble;
  private MarbleSolitaireModelState.SlotState empty;
  private MarbleSolitaireModelState.SlotState invalid;
  private MarbleSolitaireModel triangleModel1;
  private MarbleSolitaireModel triangleModel2;
  private MarbleSolitaireModel triangleModel3;
  private MarbleSolitaireModel triangleModel4;

  @Before
  public void setUp() {
    this.empty = MarbleSolitaireModelState.SlotState.Empty;
    this.marble = MarbleSolitaireModelState.SlotState.Marble;
    this.invalid = MarbleSolitaireModelState.SlotState.Invalid;
    this.triangleModel1 = new TriangleSolitaireModel();
    this.triangleModel2 = new TriangleSolitaireModel(3, 1);
    this.triangleModel3 = new TriangleSolitaireModel(7);
    this.triangleModel4 = new TriangleSolitaireModel(7, 3, 3);
  }

  @Test
  public void testTriangleWrongLength1() {
    try {
      new TriangleSolitaireModel(-1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_INTEGER.toString());
    }
  }

  @Test
  public void testTriangleWrongLength2() {
    try {
      new TriangleSolitaireModel(0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_INTEGER.toString());
    }
  }

  @Test
  public void testTriangleWrongLength3() {
    try {
      new TriangleSolitaireModel(-1, 0, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.POSITIVE_INTEGER.toString());
    }
  }


  @Test
  public void testTriangleWrongEmptySlotPosition1() {
    try {
      new TriangleSolitaireModel(-1, -1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), -1, -1));
    }
  }

  @Test
  public void testTriangleWrongEmptySlotPosition2() {
    try {
      new TriangleSolitaireModel(0, 1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), 0, 1));
    }
  }

  @Test
  public void testTriangleWrongEmptySlotPosition3() {
    try {
      new EnglishSolitaireModel(7, 0, 1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(),
              String.format(ErrorStatus.INVALID_EMPTY_SLOT.toString(), 0, 1));
    }
  }


  @Test
  public void testTriangleMoveLeft() {
    // Game1:
    // Move (3, 3) to (3, 1)
    assertEquals(this.marble, this.triangleModel2.getSlotAt(3, 3));
    assertEquals(this.marble, this.triangleModel2.getSlotAt(3, 2));
    assertEquals(this.empty, this.triangleModel2.getSlotAt(3, 1));
    this.triangleModel2.move(3, 3, 3, 1);
    assertEquals(this.empty, this.triangleModel2.getSlotAt(3, 3));
    assertEquals(this.empty, this.triangleModel2.getSlotAt(3, 2));
    assertEquals(this.marble, this.triangleModel2.getSlotAt(3, 1));
  }

  @Test
  public void testTriangleMoveRight() {
    // Game1:
    // Move (3, 1) to (3, 3)
    assertEquals(this.marble, this.triangleModel4.getSlotAt(3, 1));
    assertEquals(this.marble, this.triangleModel4.getSlotAt(3, 2));
    assertEquals(this.empty, this.triangleModel4.getSlotAt(3, 3));
    this.triangleModel4.move(3, 1, 3, 3);
    assertEquals(this.empty, this.triangleModel4.getSlotAt(3, 1));
    assertEquals(this.empty, this.triangleModel4.getSlotAt(3, 2));
    assertEquals(this.marble, this.triangleModel4.getSlotAt(3, 3));
  }

  @Test
  public void testTriangleMoveUp() {
    // Game1:
    // Move (5, 3) to (3, 3)
    assertEquals(this.marble, this.triangleModel4.getSlotAt(5, 3));
    assertEquals(this.marble, this.triangleModel4.getSlotAt(4, 3));
    assertEquals(this.empty, this.triangleModel4.getSlotAt(3, 3));
    this.triangleModel4.move(5, 3, 3, 3);
    assertEquals(this.empty, this.triangleModel4.getSlotAt(5, 3));
    assertEquals(this.empty, this.triangleModel4.getSlotAt(4, 3));
    assertEquals(this.marble, this.triangleModel4.getSlotAt(3, 3));
  }

  @Test
  public void testTriangleMoveUp2() {
    MarbleSolitaireModel model = new TriangleSolitaireModel(1, 1);

    // Game1:
    // Move (3, 1) to (1, 1)
    assertEquals(this.marble, model.getSlotAt(3, 1));
    assertEquals(this.marble, model.getSlotAt(2, 1));
    assertEquals(this.empty, model.getSlotAt(1, 1));
    model.move(3, 1, 1, 1);
    assertEquals(this.empty, model.getSlotAt(3, 1));
    assertEquals(this.empty, model.getSlotAt(2, 1));
    assertEquals(this.marble, model.getSlotAt(1, 1));
  }

  @Test
  public void testTriangleMoveDownLeft() {
    // Game1:
    // Move (1, 1) to (3, 1)
    assertEquals(this.marble, this.triangleModel2.getSlotAt(1, 1));
    assertEquals(this.marble, this.triangleModel2.getSlotAt(2, 1));
    assertEquals(this.empty, this.triangleModel2.getSlotAt(3, 1));
    this.triangleModel2.move(1, 1, 3, 1);
    assertEquals(this.empty, this.triangleModel2.getSlotAt(1, 1));
    assertEquals(this.empty, this.triangleModel2.getSlotAt(2, 1));
    assertEquals(this.marble, this.triangleModel2.getSlotAt(3, 1));
  }

  @Test
  public void testTriangleMoveDownRightSlant() {
    // Game1:
    // Move (1, 1) to (3, 3)
    assertEquals(this.marble, this.triangleModel4.getSlotAt(1, 1));
    assertEquals(this.marble, this.triangleModel4.getSlotAt(2, 2));
    assertEquals(this.empty, this.triangleModel4.getSlotAt(3, 3));
    this.triangleModel4.move(1, 1, 3, 3);
    assertEquals(this.empty, this.triangleModel4.getSlotAt(1, 1));
    assertEquals(this.empty, this.triangleModel4.getSlotAt(2, 2));
    assertEquals(this.marble, this.triangleModel4.getSlotAt(3, 3));
  }

  @Test
  public void testTriangleInvalidMoveFromEmptyToMarble() {
    try {
      this.triangleModel1.move(0, 0, 2, 2);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testTriangleInvalidMoveJumpToNotEmpty() {
    try {
      this.triangleModel1.move(2, 0, 2, 2);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testTriangleInvalidMoveJumpOverEmpty() {
    try {
      this.triangleModel2.move(4, 1, 2, 1);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testTriangleInvalidMoveMoreThanTwoApart() {
    try {
      this.triangleModel1.move(3, 3, 0, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }

  @Test
  public void testTriangleInvalidMoveOneApart() {
    try {
      this.triangleModel1.move(1, 1, 0, 0);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.INVALID_MOVE.toString());
    }
  }


  @Test
  public void testTriangleIsGameOver() {
    MarbleSolitaireModel noMarbles = new TriangleSolitaireModel(1);
    assertTrue(noMarbles.isGameOver());
    assertFalse(this.triangleModel1.isGameOver());
  }

  @Test
  public void testTriangleGetBoardSize() {
    assertEquals(5, this.triangleModel1.getBoardSize());
    assertEquals(5, this.triangleModel2.getBoardSize());
    assertEquals(7, this.triangleModel3.getBoardSize());
    assertEquals(7, this.triangleModel4.getBoardSize());
  }

  @Test
  public void testTriangleGetSlotAt() {
    assertEquals(this.invalid, this.triangleModel1.getSlotAt(0, 1));
    assertEquals(this.marble, this.triangleModel1.getSlotAt(3, 2));
    assertEquals(this.empty, this.triangleModel1.getSlotAt(0, 0));
  }

  @Test
  public void testTriangleGetScore() {
    assertEquals(14, this.triangleModel1.getScore());
    this.triangleModel1.move(2, 2, 0, 0);
    assertEquals(13, this.triangleModel1.getScore());
    this.triangleModel1.move(2, 0, 2, 2);
    assertEquals(12, this.triangleModel1.getScore());
  }
}
