import org.junit.Test;

import java.io.InputStreamReader;
import java.io.StringReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireView;
import cs3500.marblesolitaire.view.MockTextView;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Tests for {@code MarbleSolitaireControllerImpl} with Triangle solitaire models.
 */
public class TriangleControllerTest {
  @Test
  public void testAllNullConstruction() {
    try {
      new MarbleSolitaireControllerImpl(null, null, null);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testModelNullConstruction() {
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model);
    Readable readable = new InputStreamReader(System.in);
    try {
      new MarbleSolitaireControllerImpl(null, view, readable);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testViewNullConstruction() {
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    Readable readable = new InputStreamReader(System.in);
    try {
      new MarbleSolitaireControllerImpl(model, null, readable);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testReadableNullConstruction() {
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model);
    try {
      new MarbleSolitaireControllerImpl(model, view, null);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testControllerIllegalStateException1() {
    try {
      MarbleSolitaireModel model = new TriangleSolitaireModel();
      // renderBoard and renderMessage methods will throw IOException
      // causing the controller to throw IllegalStateException.
      MarbleSolitaireView view = new MockTextView();
      Readable readable = new StringReader("2 2 0 0 q");
      MarbleSolitaireController controller =
              new MarbleSolitaireControllerImpl(model, view, readable);
      controller.playGame();
      fail("error");
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), ErrorStatus.IOEXCEPTION_CAUGHT.toString());
    }
  }

  @Test
  public void testControllerIllegalStateException2() {
    try {
      MarbleSolitaireModel model = new TriangleSolitaireModel();
      MarbleSolitaireView view = new TriangleSolitaireTextView(model);
      // Empty string reader will cause IOException, which will cause controller to
      // throw an IllegalStateException.
      Readable readable = new StringReader("");
      MarbleSolitaireController controller =
              new MarbleSolitaireControllerImpl(model, view, readable);
      controller.playGame();
      fail("error");
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), ErrorStatus.IOEXCEPTION_CAUGHT.toString());
    }
  }

  @Test
  public void testPlayGameAndQuit() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("Q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n");
  }

  @Test
  public void testPlayGameAndQuit2() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("3 Q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n");
  }

  @Test
  public void testPlayGameAndQuit3() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("3 3 Q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n");
  }

  @Test
  public void testPlayGameAndQuit4() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("3 3 1 Q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n");
  }

  @Test
  public void testPlayGameWithValidMovesAndQuit() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("3 3 1 1 q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "    O\n" +
                    "   O _\n" +
                    "  O O _\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 13\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O\n" +
                    "   O _\n" +
                    "  O O _\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 13\n");
  }

  @Test
  public void testPlayInvalidMoveAndQuit() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("1 2 3 4 q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "Invalid move. Play again.\n" +
                    "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n");
  }

  @Test
  public void testPlayGibberishAndNegativeNumsAndQuit() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("3 hi -1 hi -200 hi hi 1 q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n");
  }

  @Test
  public void testPlayValidPosThenInvalidThenValid() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("3 3 hi -1 there -200 1 hi 1 q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "    O\n" +
                    "   O _\n" +
                    "  O O _\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 13\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O\n" +
                    "   O _\n" +
                    "  O O _\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 13\n");
  }

  @Test
  public void testPlayGameAndGameOver() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);
    Readable readable = new StringReader(
            "3 3 1 1\n" +
                    "3 1 3 3\n" +
                    "1 1 3 1\n" +
                    "4 1 2 1\n" +
                    "5 4 3 2\n" +
                    "2 1 3 3\n" +
                    "2 1 4 3\n" +
                    "5 3 3 1\n" +
                    "4 4 4 2\n" +
                    "3 1 5 3\n" +
                    "5 2 5 4\n" +
                    "5 5 5 3\n");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 14\n" +
                    "    O\n" +
                    "   O _\n" +
                    "  O O _\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 13\n" +
                    "    O\n" +
                    "   O _\n" +
                    "  _ _ O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 12\n" +
                    "    _\n" +
                    "   _ _\n" +
                    "  O _ O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "Score: 11\n" +
                    "    _\n" +
                    "   O _\n" +
                    "  _ _ O\n" +
                    " _ O O O\n" +
                    "O O O O O\n" +
                    "Score: 10\n" +
                    "    _\n" +
                    "   O _\n" +
                    "  _ O O\n" +
                    " _ O _ O\n" +
                    "O O O _ O\n" +
                    "Score: 9\n" +
                    "Invalid move. Play again.\n" +
                    "    _\n" +
                    "   O _\n" +
                    "  _ O O\n" +
                    " _ O _ O\n" +
                    "O O O _ O\n" +
                    "Score: 9\n" +
                    "    _\n" +
                    "   _ _\n" +
                    "  _ _ O\n" +
                    " _ O O O\n" +
                    "O O O _ O\n" +
                    "Score: 8\n" +
                    "    _\n" +
                    "   _ _\n" +
                    "  O _ O\n" +
                    " _ _ O O\n" +
                    "O O _ _ O\n" +
                    "Score: 7\n" +
                    "    _\n" +
                    "   _ _\n" +
                    "  O _ O\n" +
                    " _ O _ _\n" +
                    "O O _ _ O\n" +
                    "Score: 6\n" +
                    "    _\n" +
                    "   _ _\n" +
                    "  _ _ O\n" +
                    " _ _ _ _\n" +
                    "O O O _ O\n" +
                    "Score: 5\n" +
                    "    _\n" +
                    "   _ _\n" +
                    "  _ _ O\n" +
                    " _ _ _ _\n" +
                    "O _ _ O O\n" +
                    "Score: 4\n" +
                    "Game over!\n" +
                    "    _\n" +
                    "   _ _\n" +
                    "  _ _ O\n" +
                    " _ _ _ _\n" +
                    "O _ O _ _\n" +
                    "Score: 3\n");
  }
}
