import org.junit.Test;

import java.io.InputStreamReader;
import java.io.StringReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;
import cs3500.marblesolitaire.view.MockTextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Tests for {@code MarbleSolitaireControllerImpl} with English solitaire models.
 */
public class EnglishControllerTest {
  @Test
  public void testAllNullConstruction() {
    try {
      new MarbleSolitaireControllerImpl(null, null, null);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testModelNullConstruction() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model);
    Readable readable = new InputStreamReader(System.in);
    try {
      new MarbleSolitaireControllerImpl(null, view, readable);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testViewNullConstruction() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    Readable readable = new InputStreamReader(System.in);
    try {
      new MarbleSolitaireControllerImpl(model, null, readable);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testReadableNullConstruction() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model);
    try {
      new MarbleSolitaireControllerImpl(model, view, null);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testControllerIllegalStateException1() {
    try {
      MarbleSolitaireModel model = new EnglishSolitaireModel();
      // renderBoard and renderMessage methods will throw IOException
      // causing the controller to throw IllegalStateException.
      MarbleSolitaireView view = new MockTextView();
      Readable readable = new StringReader("4 2 4 4 q");
      MarbleSolitaireController controller =
              new MarbleSolitaireControllerImpl(model, view, readable);
      controller.playGame();
      fail("error");
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), ErrorStatus.IOEXCEPTION_CAUGHT.toString());
    }
  }

  @Test
  public void testControllerIllegalStateException2() {
    try {
      MarbleSolitaireModel model = new EnglishSolitaireModel();
      MarbleSolitaireView view = new MarbleSolitaireTextView(model);
      // Empty string reader will cause IOException, which will cause controller to
      // throw an IllegalStateException.
      Readable readable = new StringReader("");
      MarbleSolitaireController controller =
              new MarbleSolitaireControllerImpl(model, view, readable);
      controller.playGame();
      fail("error");
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), ErrorStatus.IOEXCEPTION_CAUGHT.toString());
    }
  }

  @Test
  public void testPlayGameAndQuit() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("Q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n");
  }

  @Test
  public void testPlayGameAndQuit2() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("4 Q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n");
  }

  @Test
  public void testPlayGameAndQuit3() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("4 2 Q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n");
  }

  @Test
  public void testPlayGameAndQuit4() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("4 2 4 Q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n");
  }

  @Test
  public void testPlayGameWithValidMovesAndQuit() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("4 2 4 4 q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 31\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 31\n");
  }

  @Test
  public void testPlayInvalidMoveAndQuit() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("1 2 3 4 q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "Invalid move. Play again.\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n");
  }

  @Test
  public void testPlayGibberishAndNegativeNumsAndQuit() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("4 hi -1 hi -200 hi hi 2 q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n");
  }

  @Test
  public void testPlayValidPosThenInvalidThenValid() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader("4 2 hi -1 there -200 4 hi 4 q");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 31\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 31\n");
  }

  @Test
  public void testPlayGameAndGameOver() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);
    Readable readable = new StringReader(
            "4 2 4 4\n" +
                    "2 3 4 3\n" +
                    "3 1 3 3\n" +
                    "5 1 3 1\n" +
                    "5 3 5 1\n" +
                    "7 3 5 2\n" +
                    "7 3 5 3\n" +
                    "7 5 7 3\n" +
                    "4 3 6 3\n" +
                    "7 3 5 3\n" +
                    "6 5 6 3\n" +
                    "6 3 4 3\n" +
                    "3 3 5 3\n" +
                    "5 4 5 2\n" +
                    "5 1 5 3\n" +
                    "3 4 5 4\n" +
                    "5 4 5 2\n" +
                    "1 4 3 4\n" +
                    "5 5 5 3\n" +
                    "5 6 5 4\n" +
                    "3 5 5 5\n" +
                    "5 4 5 6\n" +
                    "5 7 5 5\n" +
                    "4 7 4 5\n" +
                    "3 7 3 5\n" +
                    "3 5 3 3\n" +
                    "5 5 3 5\n" +
                    "2 5 4 5\n");
    MarbleSolitaireController controller =
            new MarbleSolitaireControllerImpl(model, view, readable);
    controller.playGame();

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 32\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 31\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O O _ O O O O\n" +
                    "O _ O O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 30\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "_ _ O O O O O\n" +
                    "O _ O O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 29\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ O O O O O\n" +
                    "_ O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 28\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 27\n" +
                    "Invalid move. Play again.\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "Score: 27\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ O O O O O\n" +
                    "O _ O O O O O\n" +
                    "    _ O O\n" +
                    "    _ O O\n" +
                    "Score: 26\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ O O O O O\n" +
                    "O _ O O O O O\n" +
                    "    _ O O\n" +
                    "    O _ _\n" +
                    "Score: 25\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ _ O O O O\n" +
                    "O _ _ O O O O\n" +
                    "    O O O\n" +
                    "    O _ _\n" +
                    "Score: 24\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ _ O O O O\n" +
                    "O _ O O O O O\n" +
                    "    _ O O\n" +
                    "    _ _ _\n" +
                    "Score: 23\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ _ O O O O\n" +
                    "O _ O O O O O\n" +
                    "    O _ _\n" +
                    "    _ _ _\n" +
                    "Score: 22\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ O O O O O\n" +
                    "_ _ O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 21\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ _ O O O O\n" +
                    "_ _ _ O O O O\n" +
                    "O _ O O O O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 20\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ _ O O O O\n" +
                    "_ _ _ O O O O\n" +
                    "O O _ _ O O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 19\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ _ O O O O\n" +
                    "_ _ _ O O O O\n" +
                    "_ _ O _ O O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 18\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ _ _ O O O\n" +
                    "_ _ _ _ O O O\n" +
                    "_ _ O O O O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 17\n" +
                    "    O O O\n" +
                    "    _ O O\n" +
                    "O _ _ _ O O O\n" +
                    "_ _ _ _ O O O\n" +
                    "_ O _ _ O O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 16\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ _ O O O O\n" +
                    "_ _ _ _ O O O\n" +
                    "_ O _ _ O O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 15\n" +
                    "Invalid move. Play again.\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ _ O O O O\n" +
                    "_ _ _ _ O O O\n" +
                    "_ O _ _ O O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 15\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ _ O O O O\n" +
                    "_ _ _ _ O O O\n" +
                    "_ O _ O _ _ O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 14\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ _ O _ O O\n" +
                    "_ _ _ _ _ O O\n" +
                    "_ O _ O O _ O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 13\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ _ O _ O O\n" +
                    "_ _ _ _ _ O O\n" +
                    "_ O _ _ _ O O\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 12\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ _ O _ O O\n" +
                    "_ _ _ _ _ O O\n" +
                    "_ O _ _ O _ _\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 11\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ _ O _ O O\n" +
                    "_ _ _ _ O _ _\n" +
                    "_ O _ _ O _ _\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 10\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ _ O O _ _\n" +
                    "_ _ _ _ O _ _\n" +
                    "_ O _ _ O _ _\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 9\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ O _ _ _ _\n" +
                    "_ _ _ _ O _ _\n" +
                    "_ O _ _ O _ _\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 8\n" +
                    "    O _ O\n" +
                    "    _ _ O\n" +
                    "O _ O _ O _ _\n" +
                    "_ _ _ _ _ _ _\n" +
                    "_ O _ _ _ _ _\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 7\n" +
                    "Game over!\n" +
                    "    O _ O\n" +
                    "    _ _ _\n" +
                    "O _ O _ _ _ _\n" +
                    "_ _ _ _ O _ _\n" +
                    "_ O _ _ _ _ _\n" +
                    "    _ _ _\n" +
                    "    _ _ _\n" +
                    "Score: 6\n");
  }
}
