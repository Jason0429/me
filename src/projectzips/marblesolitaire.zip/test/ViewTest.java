import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.ErrorStatus;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;
import cs3500.marblesolitaire.view.MockTextView;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Tests for MarbleSolitaireTextView and TriangleSolitaireTextView.
 * Includes testing English, European, and Triangle views.
 */
public class ViewTest {
  MarbleSolitaireView englishView1;
  MarbleSolitaireView englishView2;
  MarbleSolitaireView englishView3;
  MarbleSolitaireView englishView4;
  MarbleSolitaireView euroView1;
  MarbleSolitaireView euroView2;
  MarbleSolitaireView euroView3;
  MarbleSolitaireView euroView4;
  MarbleSolitaireView triangleView1;
  MarbleSolitaireView triangleView2;
  MarbleSolitaireView triangleView3;
  MarbleSolitaireView triangleView4;


  @Before
  public void setUp() throws Exception {
    this.englishView1 = new MarbleSolitaireTextView(new EnglishSolitaireModel());
    this.englishView2 = new MarbleSolitaireTextView(new EnglishSolitaireModel(1));
    this.englishView3 = new MarbleSolitaireTextView(new EnglishSolitaireModel(0, 3));
    this.englishView4 = new MarbleSolitaireTextView(new EnglishSolitaireModel(5, 6, 5));
    this.euroView1 = new MarbleSolitaireTextView(new EuropeanSolitaireModel());
    this.euroView2 = new MarbleSolitaireTextView(new EuropeanSolitaireModel(1));
    this.euroView3 = new MarbleSolitaireTextView(new EuropeanSolitaireModel(3, 2));
    this.euroView4 = new MarbleSolitaireTextView(new EuropeanSolitaireModel(5, 3, 2));
    this.triangleView1 = new TriangleSolitaireTextView(new TriangleSolitaireModel());
    this.triangleView2 = new TriangleSolitaireTextView(new TriangleSolitaireModel(7));
    this.triangleView3 = new TriangleSolitaireTextView(new TriangleSolitaireModel(3, 3));
    this.triangleView4 = new TriangleSolitaireTextView(new TriangleSolitaireModel(7, 3, 3));
  }

  @Test
  public void testNullStateMarbleSolitaireTextViewConstruction() {
    try {
      new MarbleSolitaireTextView(null);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testNullStateTriangleSolitaireTextViewConstruction() {
    try {
      new TriangleSolitaireTextView(null);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testNullStateAndAppendableMarbleSolitaireTextViewConstruction() {
    try {
      new MarbleSolitaireTextView(null, null);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testNullStateAndAppendableTriangleSolitaireTextViewConstruction() {
    try {
      new TriangleSolitaireTextView(null, null);
      fail("error");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), ErrorStatus.NULL_ARGUMENTS.toString());
    }
  }

  @Test
  public void testEnglishToString() {
    assertEquals(this.englishView2.toString(), "_");
    assertEquals(this.englishView1.toString(),
            "    O O O\n"
                    + "    O O O\n"
                    + "O O O O O O O\n"
                    + "O O O _ O O O\n"
                    + "O O O O O O O\n"
                    + "    O O O\n"
                    + "    O O O");
    assertEquals(this.englishView3.toString(),
            "    O _ O\n"
                    + "    O O O\n"
                    + "O O O O O O O\n"
                    + "O O O O O O O\n"
                    + "O O O O O O O\n"
                    + "    O O O\n"
                    + "    O O O");
    assertEquals(this.englishView4.toString(),
            "        O O O O O\n"
                    + "        O O O O O\n"
                    + "        O O O O O\n"
                    + "        O O O O O\n"
                    + "O O O O O O O O O O O O O\n"
                    + "O O O O O O O O O O O O O\n"
                    + "O O O O O _ O O O O O O O\n"
                    + "O O O O O O O O O O O O O\n"
                    + "O O O O O O O O O O O O O\n"
                    + "        O O O O O\n"
                    + "        O O O O O\n"
                    + "        O O O O O\n"
                    + "        O O O O O");
  }

  @Test
  public void testEuroToString() {
    assertEquals(this.euroView1.toString(),
            "    O O O\n" +
                    "  O O O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "  O O O O O\n" +
                    "    O O O");
    assertEquals(this.euroView2.toString(), "_");
    assertEquals(this.euroView3.toString(),
            "    O O O\n" +
                    "  O O O O O\n" +
                    "O O O O O O O\n" +
                    "O O _ O O O O\n" +
                    "O O O O O O O\n" +
                    "  O O O O O\n" +
                    "    O O O");
    assertEquals(this.euroView4.toString(),
            "        O O O O O\n" +
                    "      O O O O O O O\n" +
                    "    O O O O O O O O O\n" +
                    "  O _ O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "  O O O O O O O O O O O\n" +
                    "    O O O O O O O O O\n" +
                    "      O O O O O O O\n" +
                    "        O O O O O");
  }

  @Test
  public void testTriangleToString() {
    assertEquals(this.triangleView1.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O");
    assertEquals(this.triangleView2.toString(),
            "      _\n" +
                    "     O O\n" +
                    "    O O O\n" +
                    "   O O O O\n" +
                    "  O O O O O\n" +
                    " O O O O O O\n" +
                    "O O O O O O O");
    assertEquals(this.triangleView3.toString(),
            "    O\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O _\n" +
                    "O O O O O");
    assertEquals(this.triangleView4.toString(),
            "      O\n" +
                    "     O O\n" +
                    "    O O O\n" +
                    "   O O O _\n" +
                    "  O O O O O\n" +
                    " O O O O O O\n" +
                    "O O O O O O O");
  }


  @Test
  public void testEnglishCorrectToStringAfterTwoMoves() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model);
    assertEquals(view.toString(),
            "    O O O\n"
                    + "    O O O\n"
                    + "O O O O O O O\n"
                    + "O O O _ O O O\n"
                    + "O O O O O O O\n"
                    + "    O O O\n"
                    + "    O O O");
    model.move(3, 1, 3, 3);
    assertEquals(view.toString(),
            "    O O O\n"
                    + "    O O O\n"
                    + "O O O O O O O\n"
                    + "O _ _ O O O O\n"
                    + "O O O O O O O\n"
                    + "    O O O\n"
                    + "    O O O");
    model.move(1, 2, 3, 2);
    assertEquals(view.toString(),
            "    O O O\n"
                    + "    _ O O\n"
                    + "O O _ O O O O\n"
                    + "O _ O O O O O\n"
                    + "O O O O O O O\n"
                    + "    O O O\n"
                    + "    O O O");
  }

  @Test
  public void testEuroCorrectToStringAfterTwoMoves() {
    MarbleSolitaireModel model = new EuropeanSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model);
    assertEquals(view.toString(),
            "    O O O\n" +
                    "  O O O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "  O O O O O\n" +
                    "    O O O");
    model.move(1, 3, 3, 3);
    assertEquals(view.toString(),
            "    O O O\n" +
                    "  O O _ O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "O O O O O O O\n" +
                    "  O O O O O\n" +
                    "    O O O");
    model.move(1, 1, 1, 3);
    assertEquals(view.toString(),
            "    O O O\n" +
                    "  _ _ O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "O O O O O O O\n" +
                    "  O O O O O\n" +
                    "    O O O");
  }

  @Test
  public void testTriangleCorrectToStringAfterTwoMoves() {
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model);
    assertEquals(view.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O");
    model.move(2, 0, 0, 0);
    assertEquals(view.toString(),
            "    O\n" +
                    "   _ O\n" +
                    "  _ O O\n" +
                    " O O O O\n" +
                    "O O O O O");
    model.move(2, 2, 2, 0);
    assertEquals(view.toString(),
            "    O\n" +
                    "   _ O\n" +
                    "  O _ _\n" +
                    " O O O O\n" +
                    "O O O O O");
  }

  @Test
  public void testRenderBoardIOException() {
    MarbleSolitaireView view = new MockTextView();
    try {
      view.renderBoard();
      fail("error");
    } catch (IOException e) {
      assertEquals(e.getMessage(), ErrorStatus.IOEXCEPTION_THROWN.toString());
    }
  }

  @Test
  public void testRenderMessageIOException() {
    MarbleSolitaireView view = new MockTextView();
    try {
      view.renderMessage("Hello");
      fail("error");
    } catch (IOException e) {
      assertEquals(e.getMessage(), ErrorStatus.IOEXCEPTION_THROWN.toString());
    }
  }

  @Test
  public void testRenderMessage() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);

    try {
      view.renderMessage("Hello there\n");
      view.renderMessage("Good bye");
      view.renderMessage(".");
    } catch (IOException e) {
      // Do nothing.
    }

    assertEquals("Hello there\nGood bye.", appendable.toString());
  }

  @Test
  public void testEnglishRenderBoard() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);

    try {
      view.renderBoard();
      appendable.append("\n");
    } catch (IOException e) {
      // Do nothing.
    }

    model.move(3, 1, 3, 3);

    try {
      view.renderBoard();
    } catch (IOException e) {
      // Do nothing.
    }

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O");
  }

  @Test
  public void testEuroRenderBoard() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new EuropeanSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, appendable);

    try {
      view.renderBoard();
      appendable.append("\n");
    } catch (IOException e) {
      // Do nothing.
    }

    model.move(3, 1, 3, 3);

    try {
      view.renderBoard();
    } catch (IOException e) {
      // Do nothing.
    }

    assertEquals(appendable.toString(),
            "    O O O\n" +
                    "  O O O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "  O O O O O\n" +
                    "    O O O\n" +
                    "    O O O\n" +
                    "  O O O O O\n" +
                    "O O O O O O O\n" +
                    "O _ _ O O O O\n" +
                    "O O O O O O O\n" +
                    "  O O O O O\n" +
                    "    O O O");
  }

  @Test
  public void testTriangleRenderBoard() {
    Appendable appendable = new StringBuilder();
    MarbleSolitaireModel model = new TriangleSolitaireModel();
    MarbleSolitaireView view = new TriangleSolitaireTextView(model, appendable);

    try {
      view.renderBoard();
      appendable.append("\n");
    } catch (IOException e) {
      // Do nothing.
    }

    model.move(2, 0, 0, 0);

    try {
      view.renderBoard();
    } catch (IOException e) {
      // Do nothing.
    }

    assertEquals(appendable.toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O\n" +
                    "    O\n" +
                    "   _ O\n" +
                    "  _ O O\n" +
                    " O O O O\n" +
                    "O O O O O");
  }
}
