package controller.gui;

public interface Features {
  void makeVisible();
  void load();

  void save();

  void apply();
}
