package view.gui;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;

import controller.gui.Features;

public interface ImageProcessingGUIView {

  void makeVisible();

  void updateImagePreview(BufferedImage img);

  String getSelectedQuery();

  String chooseExportLocation();

  String chooseLoadLocation();

  int askForIntegerValue(String valueName, int defaultValue, int min, int max, int increment);

  void showError(String message);

  void addFeatures(Features features);
}
