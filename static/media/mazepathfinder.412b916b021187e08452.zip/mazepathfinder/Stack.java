import tester.Tester;

class Stack<T> implements ICollection<T> {
  Deque<T> stack;

  Stack() {
    this.stack = new Deque<T>();
  }

  // Enqueues element to stack.
  public void add(T elem) {
    this.stack.addAtHead(elem);
  }

  // Dequeues element from stack.
  public T remove() {
    return this.stack.removeFromHead();
  }

  // Produces the size of the stack.
  public int size() {
    return this.stack.size();
  }

  // Returns true if stack is empty.
  public boolean isEmpty() {
    return this.size() == 0;
  }

  // Clears stack.
  public void clear() {
    this.stack.clear();
  }
}

// Tests for Stack
class ExamplesStack {
  ICollection<Integer> mtStack;
  ICollection<Integer> stack1;
  ICollection<Integer> stack2;

  // Initialize conditions.
  void init() {
    this.mtStack = new Stack<Integer>();
    this.stack1 = new Stack<Integer>();
    this.stack1.add(1);
    this.stack2 = new Stack<Integer>();
    this.stack2.add(1);
    this.stack2.add(2);
  }

  // Tests add method for Queue.
  void testAdd(Tester t) {
    this.init();

    t.checkExpect(this.mtStack.size(), 0);
    this.mtStack.add(1);
    t.checkExpect(this.mtStack.size(), 1);
    t.checkExpect(this.mtStack.remove(), 1);

    this.init();

    this.mtStack.add(1);
    this.mtStack.add(2);
    t.checkExpect(this.mtStack.size(), 2);
  }

  // Tests remove method for Queue.
  void testRemove(Tester t) {
    this.init();

    t.checkExpect(this.mtStack.size(), 0);
    t.checkException(
        new RuntimeException("Cannot remove node from empty list."),
        this.mtStack, "remove");

    t.checkExpect(this.stack1.size(), 1);
    t.checkExpect(this.stack1.remove(), 1);
    t.checkExpect(this.stack1.size(), 0);

    t.checkExpect(this.stack2.size(), 2);
    t.checkExpect(this.stack2.remove(), 2);
    t.checkExpect(this.stack2.remove(), 1);
    t.checkExpect(this.stack1.size(), 0);
  }

  // Tests size method for Queue.
  void testSize(Tester t) {
    this.init();

    t.checkExpect(this.mtStack.size(), 0);
    t.checkExpect(this.stack1.size(), 1);
    t.checkExpect(this.stack2.size(), 2);
  }

  // Tests isEmpty method for Queue.
  void testIsEmpty(Tester t) {
    this.init();

    t.checkExpect(this.mtStack.isEmpty(), true);
    t.checkExpect(this.stack1.isEmpty(), false);
    t.checkExpect(this.stack2.isEmpty(), false);
  }

  // Tests clear method for Queue.
  void testClear(Tester t) {
    this.init();

    t.checkExpect(this.mtStack.size(), 0);
    this.mtStack.clear();
    t.checkExpect(this.mtStack.size(), 0);

    t.checkExpect(this.stack1.size(), 1);
    this.stack1.clear();
    t.checkExpect(this.stack1.size(), 0);

    t.checkExpect(this.stack2.size(), 2);
    this.stack2.clear();
    t.checkExpect(this.stack2.size(), 0);
  }
}
