import java.util.function.Predicate;
import tester.Tester;

// Represents the class for Deque.
class Deque<T> {
  Sentinel<T> header;

  Deque() {
    this.header = new Sentinel<T>();
  }

  Deque(Sentinel<T> header) {
    this.header = header;
  }

  // Returns the total number of Nodes.
  // Not including Sentinel.
  int size() {
    return this.header.next.size();
  }

  // Inserts new Node at front of list.
  void addAtHead(T data) {
    this.header.addAtHead(data);
  }

  // Inserts new Node at tail of list.
  void addAtTail(T data) {
    this.header.addAtTail(data);
  }

  // Removes node at head of list.
  T removeFromHead() {
    return this.header.next.remove();
  }

  // Removes node at tail of list.
  T removeFromTail() {
    return this.header.prev.remove();
  }

  // Returns the first node for which the given predicate returns true.
  ANode<T> find(Predicate<T> pred) {
    return this.header.next.find(pred);
  }

  // Removes given node from list.
  void removeNode(ANode<T> node) {
    node.remove();
  }

  // Clears deque.
  void clear() {
    this.header.next = this.header;
    this.header.prev = this.header;
  }
}

// Represents the abstract class for Node.
abstract class ANode<T> {
  ANode<T> prev;
  ANode<T> next;

  ANode() {

  }

  ANode(ANode<T> next, ANode<T> prev) {
    this.next = next;
    this.prev = prev;
  }

  // Returns number of Nodes in list.
  abstract int size();

  // Removes this node from list.
  abstract T remove();

  // Returns the first node for which the given predicate returns true.
  abstract ANode<T> find(Predicate<T> pred);
}

// Represents the class for Node.
class Node<T> extends ANode<T> {
  T data;

  Node(T data) {
    super(null, null);
    this.data = data;
  }

  Node(T data, ANode<T> next, ANode<T> prev) {
    super(next, prev);
    this.data = data;

    if (next == null || prev == null) {
      throw new IllegalArgumentException("Arguments cannot be null.");
    }

    this.prev.next = this;
    this.next.prev = this;
  }

  // Helper for size.
  @Override
  int size() {
    return 1 + this.next.size();
  }

  // Removes this node from list.
  @Override
  T remove() {
    this.prev.next = this.next;
    this.next.prev = this.prev;
    return this.data;
  }

  // Helper for find.
  @Override
  ANode<T> find(Predicate<T> pred) {
    return pred.test(this.data) ? this : this.next.find(pred);
  }
}

// Represents the class for Sentinel.
class Sentinel<T> extends ANode<T> {
  Sentinel() {
    this.prev = this;
    this.next = this;
  }

  // Returns the total number of Nodes.
  // Not including Sentinel.
  int size() {
    return 0;
  }

  // Inserts new Node at front of list.
  void addAtHead(T data) {
    this.next = new Node<T>(data, this.next, this);
  }

  // Inserts new Node at tail of list.
  void addAtTail(T data) {
    this.prev = new Node<T>(data, this, this.prev);
  }

  // Removes this node from list.
  @Override
  T remove() {
    throw new RuntimeException("Cannot remove node from empty list.");
  }

  // Returns the first node for which the given predicate returns true.
  ANode<T> find(Predicate<T> pred) {
    return this;
  }
}

// Represents a predicate that checks if two strings are equal to each other.
class StringComparator implements Predicate<String> {
  String s1;

  StringComparator(String s1) {
    this.s1 = s1;
  }

  // Checks if two strings are equal to each other.
  public boolean test(String s2) {
    return this.s1.equals(s2);
  }
}

class ExamplesDeque {
  // Sentinels
  Sentinel<String> sen1;
  Sentinel<String> sen2;
  Sentinel<String> sen3;

  // Example Nodes (Ordered)
  Node<String> abc;
  Node<String> bcd;
  Node<String> cde;
  Node<String> def;

  // Example Nodes (Unordered)
  Node<String> a;
  Node<String> b;
  Node<String> c;
  Node<String> d;

  // Deques
  Deque<String> deque1;
  Deque<String> deque2;
  Deque<String> deque3;

  // Initialize conditions.
  void initConditions() {
    // Sentinels
    sen1 = new Sentinel<String>();
    sen2 = new Sentinel<String>();
    sen3 = new Sentinel<String>();

    // Example Nodes (Ordered)
    // abc <-> bcd <-> cde <-> def
    // def <-> sen2 <-> abc
    abc = new Node<String>("abc", this.sen2, this.sen2);
    bcd = new Node<String>("bcd", this.sen2, this.abc);
    cde = new Node<String>("cde", this.sen2, this.bcd);
    def = new Node<String>("def", this.sen2, this.cde);

    // Example Nodes (Unordered)
    // b <-> a <-> d <-> c
    // c <-> sen3 <-> b
    b = new Node<String>("b", this.sen3, this.sen3);
    a = new Node<String>("a", this.sen3, this.b);
    d = new Node<String>("d", this.sen3, this.a);
    c = new Node<String>("c", this.sen3, this.d);

    // Deques
    deque1 = new Deque<String>(this.sen1);
    deque2 = new Deque<String>(this.sen2);
    deque3 = new Deque<String>(this.sen3);
  }

  // Tests size method for Deque, Sentinel, Node.
  void testSize(Tester t) {
    this.initConditions();

    t.checkExpect(this.deque1.size(), 0);
    t.checkExpect(this.deque2.size(), 4);
    t.checkExpect(this.deque3.size(), 4);

    t.checkExpect(this.sen1.size(), 0);
    t.checkExpect(this.sen2.size(), 0);
    t.checkExpect(this.sen3.size(), 0);

    t.checkExpect(this.abc.size(), 4);
    t.checkExpect(this.d.size(), 2);
  }

  // Tests addAtHead method for Deque, Sentinel.
  void testAddAtHead(Tester t) {
    this.initConditions();

    t.checkExpect(this.deque1.header.next, this.sen1);
    this.deque1.addAtHead("hi");
    Node<String> node1AddAtHead = new Node<String>("hi", this.sen1, this.sen1);
    t.checkExpect(this.deque1.header.next, node1AddAtHead);
  }

  // Tests addAtTail method for Deque, Sentinel.
  void testAddAtTail(Tester t) {
    this.initConditions();

    t.checkExpect(this.deque1.header.prev, this.sen1);
    this.deque1.addAtHead("hi");
    Node<String> node1AddAtTail = new Node<String>("hi", this.sen1, this.sen1);
    t.checkExpect(this.deque1.header.prev, node1AddAtTail);
  }

  // Tests removeFromHead method for Deque.
  void testRemoveFromHead(Tester t) {
    this.initConditions();

    t.checkException(
        new RuntimeException("Cannot remove node from empty list."),
        this.deque1, "removeFromHead");

    t.checkExpect(this.deque2.header.next, this.abc);
    t.checkExpect(this.deque2.removeFromHead(), "abc");
    t.checkExpect(this.deque2.header.next, this.bcd);
  }

  // Tests removeFromTail method for Sentinel, Deque.
  void testRemoveFromTail(Tester t) {
    this.initConditions();

    t.checkException(
        new RuntimeException("Cannot remove node from empty list."),
        this.deque1, "removeFromTail");

    t.checkExpect(this.deque2.header.prev, this.def);
    t.checkExpect(this.deque2.removeFromTail(), "def");
    t.checkExpect(this.deque2.header.prev, this.cde);
  }

  // Tests remove method for ANode, Node, Sentinel.
  void testRemove(Tester t) {
    this.initConditions();

    t.checkException(
        new RuntimeException("Cannot remove node from empty list."),
        this.sen1, "remove");

    t.checkExpect(this.sen2.next, this.abc);
    t.checkExpect(this.bcd.prev, this.abc);
    t.checkExpect(this.abc.remove(), "abc");
    t.checkExpect(this.sen2.next, this.bcd);
    t.checkExpect(this.bcd.prev, this.sen2);
  }

  // Tests find method for Deque, Sentinel.
  void testFind(Tester t) {
    this.initConditions();

    Predicate<String> pred = new StringComparator("abc");
    t.checkExpect(this.deque1.find(pred), this.sen1);
    t.checkExpect(this.deque2.find(pred), this.abc);
    t.checkExpect(this.sen1.find(pred), this.sen1);
    t.checkExpect(this.sen2.find(pred), this.sen2);
  }

  // Tests removeNode method for Deque.
  void testRemoveNode(Tester t) {
    this.initConditions();

    t.checkExpect(this.deque2.header.next, this.abc);
    this.deque2.removeNode(this.abc);
    t.checkExpect(this.deque2.header.next, this.bcd);

    this.initConditions();

    t.checkExpect(this.abc.next, this.bcd);
    t.checkExpect(this.cde.prev, this.bcd);
    this.deque2.removeNode(this.bcd);
    t.checkExpect(this.abc.next, this.cde);
    t.checkExpect(this.cde.prev, this.abc);
  }

  // Tests clear method for Deque.
  void testClear(Tester t) {
    this.initConditions();

    t.checkExpect(this.deque1.size(), 0);
    t.checkExpect(this.deque2.size(), 4);
    t.checkExpect(this.deque3.size(), 4);

    this.deque1.clear();
    this.deque2.clear();
    this.deque3.clear();

    t.checkExpect(this.deque1.size(), 0);
    t.checkExpect(this.deque2.size(), 0);
    t.checkExpect(this.deque3.size(), 0);
  }
}