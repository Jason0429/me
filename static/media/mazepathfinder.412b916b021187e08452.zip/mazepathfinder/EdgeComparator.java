import java.util.Comparator;
import java.util.Random;

import tester.Tester;

// Represents comparator class for Edges.
class EdgeComparator implements Comparator<Edge> {
  // Compares weights of edges.
  @Override
  public int compare(Edge e1, Edge e2) {
    return e1.weight - e2.weight;
  }
}

// Tests for EdgeComparator
class ExamplesEdgeComparator {
  Comparator<Edge> edgeComp;
  Vertex v1;
  Vertex v2;
  Edge e1;
  Edge e2;
  Edge e3;

  // Initialize conditions.
  void init() {
    this.edgeComp = new EdgeComparator();
    this.v1 = new Vertex(0, 0);
    this.v2 = new Vertex(1, 1);
    Random r1 = new Random(1);
    Random r2 = new Random(2);
    Random r3 = new Random(1);
    this.e1 = new Edge(this.v1, this.v2, r1);
    this.e2 = new Edge(this.v1, this.v2, r2);
    this.e3 = new Edge(this.v1, this.v2, r3);
  }

  // Tests compare method for EdgeComparator.
  void testCompare(Tester t) {
    this.init();

    t.checkExpect(this.edgeComp.compare(this.e1, this.e1), 0);
    t.checkExpect(this.edgeComp.compare(this.e1, this.e3), 0);
    t.checkExpect(this.edgeComp.compare(this.e1, this.e2), 27);
    t.checkExpect(this.edgeComp.compare(this.e2, this.e1), -27);
  }
}