import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Random;
import javalib.impworld.*;
import javalib.worldimages.OutlineMode;
import javalib.worldimages.RectangleImage;
import javalib.worldimages.WorldImage;
import tester.Tester;

import java.awt.Color;

// Represents class for Maze game.
class Maze extends World {
  WorldScene scene;
  int screenWidth;
  int screenHeight;
  int cols;
  int rows;
  int cellSize;
  int speed;
  ArrayList<ArrayList<Vertex>> maze;
  HashMap<Vertex, Vertex> vertexMap;
  ArrayList<Edge> mst;
  Random rand;
  Vertex start;
  Vertex end;
  Vertex player;
  boolean ready;

  // On tick renders:
  ICollection<Vertex> visitedVertices;
  ICollection<Vertex> solutionVertices;

  // Static variables
  static double TICK_RATE = 1.0 / 100.0;
  static Color START_COLOR = Color.GREEN;
  static Color END_COLOR = Color.MAGENTA.darker().darker();
  static Color VISITED_COLOR = Color.CYAN;
  static Color SOLUTION_COLOR = Color.BLUE;
  static Color WALL_COLOR = Color.BLACK;
  static Color CELL_COLOR = Color.WHITE;
  static Color PLAYER_COLOR = Color.GRAY;
  static Color PLAYER_PATH_COLOR = Color.YELLOW;
  static int TESTING_CELL_SIZE = 40;

  Maze(int rows, int cols) {
    this(rows, cols, new Random());
  }

  Maze(int rows, int cols, Random rand) {
    this.checkValidDimensions(rows, cols);
    this.screenWidth = 1200;
    this.rand = rand;
    this.scene = this.getEmptyScene();
    this.rows = rows;
    this.cols = cols;
    this.cellSize = this.screenWidth / cols > 40
        ? 40
        : this.screenWidth / cols;
    this.screenHeight = rows * this.cellSize + 20;
    this.speed = this.getSpeed();
    this.reset();
  }

  // Resets the maze.
  public void reset() {
    this.ready = false;
    this.visitedVertices = new Queue<Vertex>();
    this.solutionVertices = new Queue<Vertex>();
    this.maze = this.getBlankMaze();
    this.vertexMap = this.getInitialVertexMap(this.maze);
    this.mst = this.getMST(this.maze);
    this.start = this.maze.get(0).get(0);
    this.player = this.start;
    this.end = this.maze.get(this.rows - 1).get(this.cols - 1);
    this.resetVertices();
  }

  // Throws exception if incorrect dimensions are given.
  public void checkValidDimensions(int rows, int cols) {
    if (rows < 2 || cols < 2) {
      throw new IllegalArgumentException("There must be at least 2 rows or columns.");
    }
  }

  // Returns number of vertices to render per tick.
  public int getSpeed() {
    if (this.rows < 50 && this.cols < 50) {
      return 1;
    }

    return Math.max(this.rows, this.cols) / 10;
  }

  // Returns a hashmap where each vertex is assigned to itself.
  public HashMap<Vertex, Vertex> getInitialVertexMap(ArrayList<ArrayList<Vertex>> maze) {
    HashMap<Vertex, Vertex> vMap = new HashMap<Vertex, Vertex>();
    for (ArrayList<Vertex> row : maze) {
      for (Vertex v : row) {
        vMap.put(v, v);
      }
    }
    return vMap;
  }

  // Gets blank maze with no vertices connected.
  public ArrayList<ArrayList<Vertex>> getBlankMaze() {
    ArrayList<ArrayList<Vertex>> newMaze = new ArrayList<ArrayList<Vertex>>();
    for (int i = 0; i < this.rows; i++) {
      ArrayList<Vertex> row = new ArrayList<Vertex>();
      for (int j = 0; j < this.cols; j++) {
        Vertex v = new Vertex(
            j * this.cellSize,
            i * this.cellSize);
        row.add(v);
      }
      newMaze.add(row);
    }
    return newMaze;
  }

  // Returns minimum spanning tree using Kruskal's algorithm.
  public ArrayList<Edge> getMST(ArrayList<ArrayList<Vertex>> maze) {
    ArrayList<Edge> sortedEdges = this.getSortedEdges(maze);
    ArrayList<Edge> mst = new ArrayList<Edge>();

    for (Edge e : sortedEdges) {
      // Checks if vertices in edge belong to same set already.
      Vertex fromRepresentative = this.find(e.from);
      Vertex toRepresentative = this.find(e.to);
      if (!fromRepresentative.equals(toRepresentative)) {
        // If they do not belong to the same set,
        // Merge the two groups.
        this.union(e.from, e.to);
        mst.add(e);
      }
    }

    return mst;
  }

  // Returns list of all walls in maze.
  public ArrayList<Edge> getSortedEdges(ArrayList<ArrayList<Vertex>> maze) {
    ArrayList<Edge> edges = new ArrayList<Edge>();
    for (int i = 0; i < this.rows; i++) {
      for (int j = 0; j < this.cols; j++) {
        Vertex v = maze.get(i).get(j);
        // Check if right exists.
        if (j < this.cols - 1) {
          Vertex right = this.maze.get(i).get(j + 1);
          edges.add(new Edge(v, right, this.rand));
        }
        // Check if bottom exists.
        if (i < this.rows - 1) {
          Vertex bottom = this.maze.get(i + 1).get(j);
          edges.add(new Edge(v, bottom, this.rand));
        }
      }
    }
    Collections.sort(edges, new EdgeComparator());
    return edges;
  }

  // Renders black background onto scene.
  public void renderBackground() {
    // Sets background as black.
    WorldImage blackBackground = new RectangleImage(
        this.screenWidth, this.screenHeight, OutlineMode.SOLID, Maze.WALL_COLOR);
    this.scene.placeImageXY(blackBackground, this.screenWidth / 2, this.screenHeight / 2);
  }

  // Renders maze board onto scene.
  public void renderMaze() {
    // Render cells and walls.
    for (ArrayList<Vertex> row : this.maze) {
      for (Vertex v : row) {
        this.scene.placeImageXY(v.draw(this.cellSize), v.x, v.y);
      }
    }
  }

  // Unions two sets together.
  public void union(Vertex v1, Vertex v2) {
    this.vertexMap.put(this.find(v1), this.find(v2));
  }

  // Finds representative of a set.
  public Vertex find(Vertex v) {
    if (this.vertexMap.get(v).equals(v)) {
      return v;
    }
    return this.find(this.vertexMap.get(v));
  }

  // Unvisits all vertices and sets its prev to null.
  public void resetVertices() {
    for (ArrayList<Vertex> row : this.maze) {
      for (Vertex v : row) {
        v.reset();
      }
    }
    this.visitedVertices.clear();
    this.solutionVertices.clear();
    this.start.color = Maze.START_COLOR;
    this.end.color = Maze.END_COLOR;
  }

  // Reconstructs solution path.
  public void reconstruct(Vertex end) {
    Vertex v = end;
    while (v != null) {
      this.solutionVertices.add(v);
      v = v.prev;
    }
  }

  // Solves the maze using breadth first search.
  public void solveBFS() {
    this.resetVertices();
    this.reconstruct(this.getPath(new Queue<Vertex>()));
  }

  // Solves the maze using depth first search.
  public void solveDFS() {
    this.resetVertices();
    this.reconstruct(this.getPath(new Stack<Vertex>()));
  }

  // Gets solution path given a queue (BFS) or stack (DFS).
  public Vertex getPath(ICollection<Vertex> worklist) {
    this.start.visited = true;
    worklist.add(this.start);

    while (!worklist.isEmpty()) {
      Vertex v = worklist.remove();

      this.visitedVertices.add(v);

      if (v.equals(this.end)) {
        return this.end;
      }

      for (Edge e : v.outgoingEdges) {
        if (!e.from.visited) {
          e.from.visited = true;
          e.from.prev = v;
          worklist.add(e.from);
        }
        if (!e.to.visited) {
          e.to.visited = true;
          e.to.prev = v;
          worklist.add(e.to);
        }
      }
    }

    return this.end;
  }

  // Moves player cell up.
  public void move(int dr, int dc) {
    // Check for adjacent null.
    int currRow = this.player.y / this.cellSize;
    int currCol = this.player.x / this.cellSize;
    int nextRow = currRow + dr;
    int nextCol = currCol + dc;

    if (nextRow >= this.rows
        || nextRow < 0
        || nextCol >= this.cols
        || nextCol < 0) {
      return;
    }

    // Check if there is wall between this and adjacent vertex.
    Vertex next = this.maze.get(nextRow).get(nextCol);
    boolean canMove = false;
    for (Edge e : next.outgoingEdges) {
      if (e.contains(this.player)) {
        canMove = true;
        break;
      }
    }

    if (canMove) {
      this.player.color = Maze.PLAYER_PATH_COLOR;
      this.player = next;
      this.player.color = Maze.PLAYER_COLOR;
    }
  }

  // Makes the scene.
  @Override
  public WorldScene makeScene() {
    this.scene = this.getEmptyScene();
    this.renderBackground();
    this.renderMaze();
    return this.scene;
  }

  // Handles key events.
  @Override
  public void onKeyEvent(String key) {
    if (key.equals("r")) {
      this.reset();
    }

    if (!this.ready) {
      return;
    }

    if (key.equals("b")) {
      this.solveBFS();
    } else if (key.equals("d")) {
      this.solveDFS();
    } else if (key.equals("up")) {
      this.move(-1, 0);
    } else if (key.equals("down")) {
      this.move(1, 0);
    } else if (key.equals("left")) {
      this.move(0, -1);
    } else if (key.equals("right")) {
      this.move(0, 1);
    }
  }

  // Handles rendering construction of maze walls.
  public void renderMazeConstruction() {
    if (this.mst.isEmpty()) {
      this.ready = true;
    } else {
      int num = this.mst.size() >= this.speed
          ? this.speed
          : this.mst.size();
      for (int i = 0; i < num; i++) {
        Edge e = this.mst.remove(0);
        if (e.from.x == e.to.x) {
          e.from.showBottomWall = false;
        }
        if (e.from.y == e.to.y) {
          e.from.showRightWall = false;
        }
        e.from.outgoingEdges.add(e);
        e.to.outgoingEdges.add(e);
      }
    }
  }

  // Handles rendering visited vertices.
  public void renderVisitedVertices() {
    if (!this.visitedVertices.isEmpty()) {
      int num = this.visitedVertices.size() >= this.speed
          ? this.speed
          : this.visitedVertices.size();
      for (int i = 0; i < num; i++) {
        Vertex v = this.visitedVertices.remove();
        v.color = Maze.VISITED_COLOR;
      }
    }
  }

  // Handles rendering solution path vertices.
  public void renderSolutionVertices() {
    // Only show solution path if visited vertices finished rendering.
    if (this.visitedVertices.isEmpty() && !this.solutionVertices.isEmpty()) {
      Vertex v = this.solutionVertices.remove();
      v.color = Maze.SOLUTION_COLOR;
    }
  }

  // Handles on tick events.
  @Override
  public void onTick() {
    if (!this.ready) {
      this.renderMazeConstruction();
    }
    this.renderVisitedVertices();
    this.renderSolutionVertices();
  }
}

// Tests Maze world.
class ExamplesMazeBigBang {
  Maze game;

  // Initialize conditions.
  void init(int rows, int cols, Random rand) {
    this.game = new Maze(rows, cols, rand);
  }

  // Creates world.
  void testBigBang(Tester t) {
    this.init(60, 100, new Random());
    this.game.bigBang(
        this.game.screenWidth, this.game.screenHeight, Maze.TICK_RATE);
  }
}

// Tests methods in Maze.
class ExamplesMaze {
  Maze game;

  // Initialize conditions.
  void init(int rows, int cols, Random rand) {
    this.game = new Maze(rows, cols, rand);
  }

  // Tests reset.
  void testReset(Tester t) {
    this.init(3, 3, new Random(1));

    this.game.reset();

    t.checkExpect(this.game.ready, false);
    t.checkExpect(this.game.visitedVertices.isEmpty(), true);
    t.checkExpect(this.game.solutionVertices.isEmpty(), true);
    t.checkExpect(this.game.maze.size(), this.game.rows);
    t.checkExpect(this.game.maze.get(0).size(), this.game.cols);
    t.checkExpect(this.game.vertexMap.size(), this.game.rows * this.game.cols);
    t.checkExpect(this.game.mst.size(), 8);
    t.checkExpect(this.game.start, this.game.maze.get(0).get(0));
    t.checkExpect(this.game.player, this.game.start);
    t.checkExpect(this.game.end, this.game.maze
        .get(this.game.rows - 1).get(this.game.cols - 1));
  }

  // Tests checkValidDimensions.
  void testCheckValidDimensions(Tester t) {
    this.init(3, 3, new Random(1));
    IllegalArgumentException exc = new IllegalArgumentException(
        "There must be at least 2 rows or columns.");

    t.checkNoException(this.game, "checkValidDimensions", 2, 2);
    t.checkNoException(this.game, "checkValidDimensions", 100, 100);
    t.checkException(exc, this.game, "checkValidDimensions", -1, -1);
    t.checkException(exc, this.game, "checkValidDimensions", 0, 0);
    t.checkException(exc, this.game, "checkValidDimensions", 1, -1);
  }

  // Tests getSpeed.
  void testGetSpeed(Tester t) {
    this.init(3, 3, new Random(1));

    t.checkExpect(this.game.getSpeed(), 1);

    this.init(50, 50, new Random(1));

    t.checkExpect(this.game.getSpeed(), 5);

    this.init(100, 100, new Random(1));

    t.checkExpect(this.game.getSpeed(), 10);
  }

  // Tests getInitialVertexMap.
  void testGetInitialVertexMap(Tester t) {
    this.init(3, 3, new Random(1));

    t.checkExpect(this.game.vertexMap.size(), this.game.rows * this.game.cols);

    HashMap<Vertex, Vertex> initMap = this.game.getInitialVertexMap(this.game.getBlankMaze());
    for (Vertex v : initMap.keySet()) {
      t.checkExpect(initMap.get(v), v);
    }
  }

  // Tests getBlankMaze.
  void testGetBlankMaze(Tester t) {
    this.init(3, 3, new Random(1));

    ArrayList<ArrayList<Vertex>> maze = this.game.getBlankMaze();
    HashMap<Vertex, Vertex> map = this.game.getInitialVertexMap(maze);

    for (ArrayList<Vertex> row : maze) {
      for (Vertex v : row) {
        t.checkExpect(map.get(v), v);
      }
    }

    t.checkExpect(maze.size(), this.game.rows);
    t.checkExpect(maze.get(0).size(), this.game.cols);
  }

  // Tests getMST.
  void testGetMST(Tester t) {
    this.init(3, 3, new Random(1));

    // Check if length of edges is greater than length of mst.
    ArrayList<Edge> sortedEdges = this.game.getSortedEdges(this.game.maze);
    ArrayList<Edge> mst = this.game.getMST(this.game.maze);
    t.checkExpect(sortedEdges.size() > mst.size(), true);

    // Check if all edges in mst belong in sortedEdges.
    boolean belongs = true;
    for (Edge e : mst) {
      if (!sortedEdges.contains(e)) {
        belongs = false;
        break;
      }
    }

    t.checkExpect(belongs, true);
  }

  // Tests getSortedEdges.
  void testGetSortedEdges(Tester t) {
    this.init(3, 3, new Random(1));

    // Check for correct number of total edges.
    ArrayList<Edge> sortedEdges = this.game.getSortedEdges(this.game.maze);
    t.checkExpect(sortedEdges.size(), 12);

    // Check if edges are sorted.
    Comparator<Edge> edgeComp = new EdgeComparator();
    boolean isSorted = true;

    for (int i = 0; i < sortedEdges.size() - 1; i++) {
      Edge e1 = sortedEdges.get(i);
      Edge e2 = sortedEdges.get(i + 1);
      if (edgeComp.compare(e1, e2) > 0) {
        isSorted = false;
        break;
      }
    }

    t.checkExpect(isSorted, true);
  }

  // Tests renderBackground.
  void testRenderBackground(Tester t) {
    this.init(3, 3, new Random(1));

    WorldScene scene = this.game.getEmptyScene();
    this.game.scene = this.game.getEmptyScene();
    this.game.renderBackground();

    WorldImage blackBackground = new RectangleImage(
        this.game.screenWidth, this.game.screenHeight, OutlineMode.SOLID, Maze.WALL_COLOR);
    scene.placeImageXY(blackBackground, this.game.screenWidth / 2, this.game.screenHeight / 2);

    t.checkExpect(this.game.scene, scene);
  }

  // Tests renderMaze.
  void testRenderMaze(Tester t) {
    this.init(3, 3, new Random(1));

    WorldScene scene = this.game.getEmptyScene();
    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        scene.placeImageXY(v.draw(this.game.cellSize), v.x, v.y);
      }
    }

    this.game.scene = this.game.getEmptyScene();
    this.game.renderMaze();
    t.checkExpect(this.game.scene, scene);
  }

  // Tests union.
  void testUnion(Tester t) {
    this.init(3, 3, new Random(1));

    Vertex v1 = new Vertex(0, 0);
    Vertex v2 = new Vertex(1, 1);
    Vertex v3 = new Vertex(1, 0);
    this.game.vertexMap = new HashMap<Vertex, Vertex>();
    this.game.vertexMap.put(v1, v1);
    this.game.vertexMap.put(v2, v2);
    this.game.vertexMap.put(v3, v3);

    this.game.union(v1, v2);
    t.checkExpect(this.game.vertexMap.get(v1), v2);
    t.checkExpect(this.game.vertexMap.get(v2), v2);
    t.checkExpect(this.game.vertexMap.get(v3), v3);

    this.game.union(v1, v3);
    t.checkExpect(this.game.vertexMap.get(v1), v2);
    t.checkExpect(this.game.vertexMap.get(v2), v3);
    t.checkExpect(this.game.vertexMap.get(v3), v3);
  }

  // Tests find.
  void testFind(Tester t) {
    this.init(3, 3, new Random(1));

    Vertex v1 = new Vertex(0, 0);
    Vertex v2 = new Vertex(1, 1);
    Vertex v3 = new Vertex(1, 0);
    this.game.vertexMap = new HashMap<Vertex, Vertex>();
    this.game.vertexMap.put(v1, v1);
    this.game.vertexMap.put(v2, v2);
    this.game.vertexMap.put(v3, v3);

    // Initialization:
    // Vertices should be set to itself.
    t.checkExpect(this.game.find(v1), v1);
    t.checkExpect(this.game.find(v2), v2);
    t.checkExpect(this.game.find(v3), v3);

    // Merging v1 and v2 should
    // put v1 and v2 in the set of v2.
    // v3 remains in its own set.
    this.game.union(v1, v2);
    t.checkExpect(this.game.find(v1), v2);
    t.checkExpect(this.game.find(v2), v2);
    t.checkExpect(this.game.find(v3), v3);

    // Merging v2 and v3 should
    // put v1, v2, and v3 in the set of v3.
    this.game.union(v2, v3);
    t.checkExpect(this.game.find(v1), v3);
    t.checkExpect(this.game.find(v2), v3);
    t.checkExpect(this.game.find(v3), v3);
  }

  // Tests resetVertices.
  void testResetVertices(Tester t) {
    this.init(3, 3, new Random(1));

    this.game.start.visited = true;
    this.game.start.color = Maze.START_COLOR;
    this.game.end.prev = this.game.start;

    this.game.resetVertices();

    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        t.checkOneOf(v.color, Maze.CELL_COLOR, Maze.START_COLOR, Maze.END_COLOR);
        t.checkExpect(v.prev, null);
        t.checkExpect(v.visited, false);
      }
    }

    t.checkExpect(this.game.visitedVertices.isEmpty(), true);
    t.checkExpect(this.game.solutionVertices.isEmpty(), true);
  }

  // Tests reconstruct.
  void testReconstruct(Tester t) {
    this.init(3, 3, new Random(1));

    t.checkExpect(this.game.solutionVertices.size(), 0);
    t.checkExpect(this.game.end.prev, null);

    // No vertices were visited before reconstruct was called.
    // All prevs were set to null before reconstruct was called.
    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        t.checkExpect(v.visited, false);
      }
    }

    this.game.reconstruct(this.game.getPath(new Queue<Vertex>()));

    // Should have visited some vertices.
    boolean didVisit = false;
    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        if (v.visited) {
          didVisit = true;
          break;
        }
      }
    }

    t.checkExpect(didVisit, true);
  }

  // Tests solveBFS.
  void testSolveBFS(Tester t) {
    this.init(3, 3, new Random(1));

    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        t.checkExpect(v.visited, false);
        t.checkExpect(v.prev, null);
        t.checkOneOf(v.color, Maze.START_COLOR, Maze.END_COLOR, Maze.CELL_COLOR);
      }
    }

    this.game.solveBFS();

    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        t.checkOneOf(v.visited, false, true);
        t.checkExpect(v.prev == null || v.prev instanceof Vertex, true);
        t.checkOneOf(v.color, Maze.CELL_COLOR, Maze.START_COLOR, Maze.END_COLOR);
      }
    }
  }

  // Tests solveDFS.
  void testSolveDFS(Tester t) {
    this.init(3, 3, new Random(1));

    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        t.checkExpect(v.visited, false);
        t.checkExpect(v.prev, null);
        t.checkOneOf(v.color, Maze.START_COLOR, Maze.END_COLOR, Maze.CELL_COLOR);
      }
    }

    this.game.solveDFS();

    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        t.checkOneOf(v.visited, false, true);
        t.checkExpect(v.prev == null || v.prev instanceof Vertex, true);
        t.checkOneOf(v.color, Maze.CELL_COLOR, Maze.START_COLOR, Maze.END_COLOR);
      }
    }
  }

  // Tests getPath.
  void testGetPath(Tester t) {
    this.init(3, 3, new Random(1));
    t.checkExpect(this.game.getPath(new Queue<Vertex>()), this.game.end);
    t.checkExpect(this.game.getPath(new Stack<Vertex>()), this.game.end);

  }

  // Tests move.
  void testMove(Tester t) {
    this.init(3, 3, new Random(1));

    // Player starts at starting vertex.
    t.checkExpect(this.game.player, this.game.start);

    // Can move anywhere.
    Vertex v1 = this.game.maze.get(0).get(0);
    Vertex v2 = this.game.maze.get(0).get(1);
    Vertex v3 = this.game.maze.get(0).get(2);
    Vertex v4 = this.game.maze.get(1).get(0);
    Vertex v5 = this.game.maze.get(1).get(1);
    Vertex v6 = this.game.maze.get(1).get(2);
    Vertex v7 = this.game.maze.get(2).get(0);
    Vertex v8 = this.game.maze.get(2).get(1);
    v1.outgoingEdges.add(new Edge(v1, v2));
    v2.outgoingEdges.add(new Edge(v2, v1));
    v1.outgoingEdges.add(new Edge(v1, v4));
    v4.outgoingEdges.add(new Edge(v4, v1));
    v2.outgoingEdges.add(new Edge(v2, v3));
    v3.outgoingEdges.add(new Edge(v3, v2));
    v2.outgoingEdges.add(new Edge(v2, v5));
    v5.outgoingEdges.add(new Edge(v5, v2));
    v3.outgoingEdges.add(new Edge(v3, v6));
    v6.outgoingEdges.add(new Edge(v6, v3));
    v4.outgoingEdges.add(new Edge(v4, v5));
    v5.outgoingEdges.add(new Edge(v5, v4));
    v4.outgoingEdges.add(new Edge(v4, v7));
    v7.outgoingEdges.add(new Edge(v7, v4));
    v5.outgoingEdges.add(new Edge(v5, v6));
    v6.outgoingEdges.add(new Edge(v6, v5));
    v5.outgoingEdges.add(new Edge(v5, v8));
    v8.outgoingEdges.add(new Edge(v8, v5));
    v6.outgoingEdges.add(new Edge(v6, v7));
    v7.outgoingEdges.add(new Edge(v7, v6));
    v7.outgoingEdges.add(new Edge(v7, v8));
    v8.outgoingEdges.add(new Edge(v8, v7));

    // Move up, can't move up
    this.game.move(-1, 0);
    t.checkExpect(this.game.player, this.game.start);

    // Move down
    this.game.move(1, 0);
    t.checkExpect(this.game.player, this.game.maze.get(1).get(0));

    // Move right
    this.game.move(0, 1);
    t.checkExpect(this.game.player, this.game.maze.get(1).get(1));

    // Move left
    this.game.move(0, -1);
    t.checkExpect(this.game.player, this.game.maze.get(1).get(0));

    this.game.player = this.game.start;

    // Remove all edges
    v1.outgoingEdges.clear();
    v2.outgoingEdges.clear();
    v3.outgoingEdges.clear();
    v4.outgoingEdges.clear();
    v5.outgoingEdges.clear();
    v6.outgoingEdges.clear();
    v7.outgoingEdges.clear();
    v8.outgoingEdges.clear();

    // Move up, can't move up
    this.game.move(-1, 0);
    t.checkExpect(this.game.player, this.game.start);

    // Move down, can't move down
    this.game.move(1, 0);
    t.checkExpect(this.game.player, this.game.start);

    // Move right, can't move right
    this.game.move(0, 1);
    t.checkExpect(this.game.player, this.game.start);

    // Move left, can't move left
    this.game.move(0, -1);
    t.checkExpect(this.game.player, this.game.start);
  }

  // Tests makeScene.
  void testMakeScene(Tester t) {
    this.init(3, 3, new Random(1));

    WorldScene scene = this.game.getEmptyScene();
    WorldImage blackBackground = new RectangleImage(
        this.game.screenWidth, this.game.screenHeight, OutlineMode.SOLID, Maze.WALL_COLOR);
    scene.placeImageXY(blackBackground, this.game.screenWidth / 2, this.game.screenHeight / 2);
    for (ArrayList<Vertex> row : this.game.maze) {
      for (Vertex v : row) {
        scene.placeImageXY(v.draw(this.game.cellSize), v.x, v.y);
      }
    }
    t.checkExpect(this.game.makeScene(), scene);
  }

  // Tests onKeyEvent.
  void testOnKeyEvent(Tester t) {
    this.init(3, 3, new Random(1));

    this.game.onKeyEvent("r");

    this.testReset(t);

    this.game.onKeyEvent("b");

    this.testSolveBFS(t);

    this.game.onKeyEvent("d");

    this.testSolveDFS(t);

    this.game.onKeyEvent("up");

    this.testMove(t);

    this.game.onKeyEvent("down");

    this.testMove(t);

    this.game.onKeyEvent("left");

    this.testMove(t);

    this.game.onKeyEvent("right");

    this.testMove(t);
  }

  // Tests renderMazeConstruction.
  void testRenderMazeConstruction(Tester t) {
    this.init(3, 3, new Random(1));

    int currSize = this.game.mst.size();
    t.checkExpect(this.game.mst.size(), currSize);

    while (!this.game.mst.isEmpty()) {
      this.game.renderMazeConstruction();
      currSize--;
      t.checkExpect(this.game.mst.size(), currSize);
    }
  }

  // Tests renderVisitedVertices.
  void testRenderVisitedVertices(Tester t) {
    this.init(3, 3, new Random(1));

    Vertex v1 = this.game.maze.get(0).get(0);
    Vertex v2 = this.game.maze.get(0).get(1);
    Vertex v3 = this.game.maze.get(0).get(2);

    this.game.visitedVertices.add(v1);
    this.game.visitedVertices.add(v2);
    this.game.visitedVertices.add(v3);

    int currSize = this.game.visitedVertices.size();
    while (!this.game.visitedVertices.isEmpty()) {
      this.game.renderVisitedVertices();
      currSize--;
      t.checkExpect(this.game.visitedVertices.size(), currSize);
    }

    t.checkExpect(v1.color, Maze.VISITED_COLOR);
    t.checkExpect(v2.color, Maze.VISITED_COLOR);
    t.checkExpect(v3.color, Maze.VISITED_COLOR);
  }

  // Tests renderSolutionVertices.
  void testRenderSolutionVertices(Tester t) {
    this.init(3, 3, new Random(1));

    Vertex v1 = this.game.maze.get(0).get(0);
    Vertex v2 = this.game.maze.get(0).get(1);
    Vertex v3 = this.game.maze.get(0).get(2);

    this.game.solutionVertices.add(v1);
    this.game.solutionVertices.add(v2);
    this.game.solutionVertices.add(v3);

    int currSize = this.game.solutionVertices.size();
    while (!this.game.solutionVertices.isEmpty()) {
      this.game.renderSolutionVertices();
      currSize--;
      t.checkExpect(this.game.solutionVertices.size(), currSize);
    }

    t.checkExpect(v1.color, Maze.SOLUTION_COLOR);
    t.checkExpect(v2.color, Maze.SOLUTION_COLOR);
    t.checkExpect(v3.color, Maze.SOLUTION_COLOR);
  }

  // Tests onTick.
  void testOnTick(Tester t) {
    // Test renderMazeConstruction
    this.init(3, 3, new Random(1));

    t.checkExpect(this.game.ready, false);

    while (!this.game.mst.isEmpty()) {
      this.game.onTick();
    }
    this.game.onTick();

    t.checkExpect(this.game.ready, true);

    // Test renderVisitedVertices
    this.init(3, 3, new Random(1));

    Vertex v1 = this.game.maze.get(0).get(0);
    Vertex v2 = this.game.maze.get(0).get(1);
    Vertex v3 = this.game.maze.get(0).get(2);

    this.game.visitedVertices.add(v1);
    this.game.visitedVertices.add(v2);
    this.game.visitedVertices.add(v3);

    int currSize = this.game.visitedVertices.size();
    while (!this.game.visitedVertices.isEmpty()) {
      this.game.onTick();
      currSize--;
      t.checkExpect(this.game.visitedVertices.size(), currSize);
    }

    t.checkExpect(v1.color, Maze.VISITED_COLOR);
    t.checkExpect(v2.color, Maze.VISITED_COLOR);
    t.checkExpect(v3.color, Maze.VISITED_COLOR);

    // Test renderSolutionVertices
    this.init(3, 3, new Random(1));

    this.game.solutionVertices.add(v1);
    this.game.solutionVertices.add(v2);
    this.game.solutionVertices.add(v3);

    currSize = this.game.solutionVertices.size();
    while (!this.game.solutionVertices.isEmpty()) {
      this.game.renderSolutionVertices();
      currSize--;
      t.checkExpect(this.game.solutionVertices.size(), currSize);
    }

    t.checkExpect(v1.color, Maze.SOLUTION_COLOR);
    t.checkExpect(v2.color, Maze.SOLUTION_COLOR);
    t.checkExpect(v3.color, Maze.SOLUTION_COLOR);
  }
}