import java.awt.Color;
import java.util.ArrayList;
import javalib.worldimages.*;
import tester.Tester;

// Represents class for a Vertex.
class Vertex {
  // For displaying to scene only.
  int x;
  int y;

  // Color of vertex.
  Color color;

  Vertex prev;

  // Edges with this vertex as the source.
  ArrayList<Edge> outgoingEdges;

  boolean visited;
  boolean isPath;
  boolean showRightWall;
  boolean showBottomWall;

  Vertex(int x, int y) {
    this.x = x;
    this.y = y;
    this.color = Maze.CELL_COLOR;
    this.outgoingEdges = new ArrayList<Edge>();
    this.prev = null;
    this.visited = false;
    this.showRightWall = true;
    this.showBottomWall = true;
  }

  // Returns true if the given Vertex equals this Vertex.
  @Override
  public boolean equals(Object o) {
    if (o instanceof Vertex) {
      Vertex v = (Vertex) o;
      return this.x == v.x && this.y == v.y;
    }
    return false;
  }

  // Hashcode override.
  @Override
  public int hashCode() {
    return (this.x * 10) + this.y;
  }

  // Produces cell as image.
  public WorldImage draw(int cellSize) {
    int width = this.showRightWall ? cellSize - 1 : cellSize;
    int height = this.showBottomWall ? cellSize - 1 : cellSize;
    double dx = -cellSize / 2;
    double dy = -cellSize / 2;
    return new RectangleImage(width, height, OutlineMode.SOLID, this.color)
        .movePinhole(dx, dy);
  }

  // Resets vertex's visited, color, and prev properties.
  public void reset() {
    this.visited = false;
    this.prev = null;
    this.color = Maze.CELL_COLOR;
  }
}

// Tests for Vertex
class ExamplesVertex {
  Vertex v1;
  Vertex v2;
  Vertex v3;
  Vertex v4;
  Vertex v5;

  // Initialize condtitions.
  void init() {
    this.v1 = new Vertex(0, 0);
    this.v2 = new Vertex(0, 1);
    this.v3 = new Vertex(1, 0);
    this.v4 = new Vertex(1, 1);
    this.v5 = new Vertex(0, 0);
  }

  // Tests equals method for Vertex.
  void testEquals(Tester t) {
    this.init();

    t.checkExpect(this.v1.equals(this.v5), true);
    t.checkExpect(this.v2.equals(this.v3), false);
    t.checkExpect(this.v4.equals(this.v4), true);
    t.checkExpect(this.v2.equals(new Edge(this.v1, this.v2)), false);
  }

  // Tests hashCode method for Vertex.
  void testHashCode(Tester t) {
    this.init();

    t.checkExpect(this.v1.hashCode(), 0);
    t.checkExpect(this.v2.hashCode(), 1);
    t.checkExpect(this.v3.hashCode(), 10);
    t.checkExpect(this.v4.hashCode(), 11);
    t.checkExpect(this.v5.hashCode(), 0);
    t.checkExpect(this.v1.hashCode() == this.v5.hashCode(), true);
    t.checkExpect(this.v1.hashCode() == this.v2.hashCode(), false);
  }

  // Tests draw method for Vertex.
  void testDraw(Tester t) {
    this.init();

    this.v1.showRightWall = false;
    this.v1.showBottomWall = false;

    this.v2.showRightWall = true;
    this.v2.showBottomWall = false;

    this.v3.showRightWall = false;
    this.v3.showBottomWall = true;

    this.v4.showRightWall = true;
    this.v4.showBottomWall = true;

    int cellSize = 5;
    double dx = -cellSize / 2;
    double dy = -cellSize / 2;

    WorldImage v1Draw = new RectangleImage(
        cellSize, cellSize, OutlineMode.SOLID, v1.color)
        .movePinhole(dx, dy);
    WorldImage v2Draw = new RectangleImage(
        cellSize - 1, cellSize, OutlineMode.SOLID, v2.color)
        .movePinhole(dx, dy);
    WorldImage v3Draw = new RectangleImage(
        cellSize, cellSize - 1, OutlineMode.SOLID, v3.color)
        .movePinhole(dx, dy);
    WorldImage v4Draw = new RectangleImage(
        cellSize - 1, cellSize - 1, OutlineMode.SOLID, v4.color)
        .movePinhole(dx, dy);

    t.checkExpect(this.v1.draw(cellSize), v1Draw);
    t.checkExpect(this.v2.draw(cellSize), v2Draw);
    t.checkExpect(this.v3.draw(cellSize), v3Draw);
    t.checkExpect(this.v4.draw(cellSize), v4Draw);
  }

  // Tests reset method for Vertex.
  void testReset(Tester t) {
    this.init();

    this.v1.color = Color.GREEN;
    this.v1.visited = true;
    this.v1.prev = this.v2;

    this.v1.reset();

    t.checkExpect(this.v1.color, Maze.CELL_COLOR);
    t.checkExpect(this.v1.visited, false);
    t.checkExpect(this.v1.prev, null);
  }
}
