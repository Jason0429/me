import java.util.Random;

import tester.Tester;

// Represents class for an Edge between two vertices.
class Edge {
  Vertex from;
  Vertex to;
  int weight;
  Random rand;

  Edge(Vertex from, Vertex to) {
    this(from, to, new Random());
  }

  // For random testing
  Edge(Vertex from, Vertex to, Random rand) {
    this.from = from;
    this.to = to;
    this.rand = rand;
    this.weight = this.rand.nextInt(50);
  }

  // Returns true if given vertex is one of the from or to vertices in edge.
  public boolean contains(Vertex v) {
    return this.from.equals(v) || this.to.equals(v);
  }
}

// Tests for Edge
class ExamplesEdge {
  Edge e1;
  Vertex v1;
  Vertex v2;
  Vertex v3;

  // Initialize condtions.
  void init() {
    this.v1 = new Vertex(0, 0);
    this.v2 = new Vertex(0, 1);
    this.v3 = new Vertex(1, 1);
    this.e1 = new Edge(this.v1, this.v2);
  }

  // Tests contains method for Edge.
  void testContains(Tester t) {
    this.init();

    t.checkExpect(this.e1.contains(this.v1), true);
    t.checkExpect(this.e1.contains(this.v2), true);
    t.checkExpect(this.e1.contains(this.v3), false);
  }
}