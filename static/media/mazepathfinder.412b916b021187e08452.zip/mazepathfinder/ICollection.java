// Represents an interface for a Collection.
interface ICollection<T> {
  // Adds element to collection.
  void add(T elem);

  // Removes an element from collection.
  T remove();

  // Produces the size of the collection.
  int size();

  // Returns true if collection is empty.
  boolean isEmpty();

  // Clears collection.
  void clear();
}
