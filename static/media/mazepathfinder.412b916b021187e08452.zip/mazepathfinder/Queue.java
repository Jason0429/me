import tester.Tester;

class Queue<T> implements ICollection<T> {
  Deque<T> queue;

  Queue() {
    this.queue = new Deque<T>();
  }

  // Enqueues element to queue.
  public void add(T elem) {
    this.queue.addAtTail(elem);
  }

  // Dequeues element from queue.
  public T remove() {
    return this.queue.removeFromHead();
  }

  // Produces the size of the queue.
  public int size() {
    return this.queue.size();
  }

  // Returns true if queue is empty.
  public boolean isEmpty() {
    return this.size() == 0;
  }

  // Clears queue.
  public void clear() {
    this.queue.clear();
  }
}

// Tests for Queue
class ExamplesQueue {
  ICollection<Integer> mtQueue;
  ICollection<Integer> queue1;
  ICollection<Integer> queue2;

  // Initialize conditions.
  void init() {
    this.mtQueue = new Queue<Integer>();
    this.queue1 = new Queue<Integer>();
    this.queue1.add(1);
    this.queue2 = new Queue<Integer>();
    this.queue2.add(1);
    this.queue2.add(2);
  }

  // Tests add method for Queue.
  void testAdd(Tester t) {
    this.init();

    t.checkExpect(this.mtQueue.size(), 0);
    this.mtQueue.add(1);
    t.checkExpect(this.mtQueue.size(), 1);
    t.checkExpect(this.mtQueue.remove(), 1);

    this.init();

    this.mtQueue.add(1);
    this.mtQueue.add(2);
    t.checkExpect(this.mtQueue.size(), 2);
  }

  // Tests remove method for Queue.
  void testRemove(Tester t) {
    this.init();

    t.checkExpect(this.mtQueue.size(), 0);
    t.checkException(
        new RuntimeException("Cannot remove node from empty list."),
        this.mtQueue, "remove");

    t.checkExpect(this.queue1.size(), 1);
    t.checkExpect(this.queue1.remove(), 1);
    t.checkExpect(this.queue1.size(), 0);

    t.checkExpect(this.queue2.size(), 2);
    t.checkExpect(this.queue2.remove(), 1);
    t.checkExpect(this.queue2.remove(), 2);
    t.checkExpect(this.queue2.size(), 0);
  }

  // Tests size method for Queue.
  void testSize(Tester t) {
    this.init();

    t.checkExpect(this.mtQueue.size(), 0);
    t.checkExpect(this.queue1.size(), 1);
    t.checkExpect(this.queue2.size(), 2);
  }

  // Tests isEmpty method for Queue.
  void testIsEmpty(Tester t) {
    this.init();

    t.checkExpect(this.mtQueue.isEmpty(), true);
    t.checkExpect(this.queue1.isEmpty(), false);
    t.checkExpect(this.queue2.isEmpty(), false);
  }

  // Tests clear method for Queue.
  void testClear(Tester t) {
    this.init();

    t.checkExpect(this.mtQueue.size(), 0);
    this.mtQueue.clear();
    t.checkExpect(this.mtQueue.size(), 0);

    t.checkExpect(this.queue1.size(), 1);
    this.queue1.clear();
    t.checkExpect(this.queue1.size(), 0);

    t.checkExpect(this.queue2.size(), 2);
    this.queue2.clear();
    t.checkExpect(this.queue2.size(), 0);
  }
}
